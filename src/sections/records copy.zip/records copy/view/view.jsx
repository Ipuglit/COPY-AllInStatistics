import { useState, useEffect } from 'react';

import Grid from '@mui/material/Unstable_Grid2';
import { Box,Stack,Container,Button,Typography,Alert,Fade,IconButton  } from '@mui/material';
import { Icon } from '@iconify/react';

import { RawRecords } from 'src/hooks/raw/';

import Loading_Skeletons from 'src/items/loaders/loadings'

import * as Data from 'src/hooks/data';
import * as Fnc from 'src/hooks/functions'
import * as Cls from 'src/hooks/classes'
import { ViaTable, ViaList, ViaTableRecord } from 'src/items/fetched';
import { OnSortings, FormattingSorting } from 'src/items/sortingFilter';

import {AddingItem} from '../upsert/form';
import { UploadRecords } from 'src/items/upload/'

import {  ModalRecordGames,
          ModalRecordDelete, 
          MenuOnSearch, 
          MenuOnFilter, 
          MenuOnEdit, 
          MenuOnDelete 
        } from 'src/items/fetched/'
// ----------------------------------------------------------------------

export default function Viewing({TheFor,TheTitle}) {

    
    const dataView  = localStorage.getItem('slk-dataview')
    const [rawRELOAD,   setrawRELOAD]       = useState(1)
    const [rawFETCH,  setrawFETCH]          = useState({
                                                          FOR:            "ALL",
                                                          STATUS:         'ACTIVE',
                                                          SORTBY:         'ALL',
                                                          SORT:           'DESC',
                                                          LIMIT:          1000,
                                                          SEARCH:         'ALL',
                                                          DATE:           'ALL',
                                                          APP:            'ALL',
                                                          CLUB:           'ALL',
                                                          PLAYER:         'ALL',
                                                          UPLINE:         'ALL',
                                                        })

    const rawItems                          = RawRecords(rawFETCH,rawRELOAD)

    const [dataLIST,  setdataLIST]          = useState({load: false, tally: 0, data: []})
    const [dataVIEW,  setdataVIEW]          = useState('new')
    const [dataGET,  setdataGET]            = useState([])

    const [sendDATA, setsendDATA]           = useState({ids: [], arrays: [] })
    const [openDelete,  setopenDelete]      = useState(false)

    useEffect(() => {

        setdataLIST({
                      load:   rawItems.load,
                      tally:  rawItems.tally,
                      data:   rawItems.data,
                    })
        setsendDATA({ids: [], arrays: [] })

    }, [rawItems.load == true]);


    const sendRELOAD =()=>{
      setrawRELOAD( rawRELOAD + 1 )
    }

    
    const handleSEARCH =(i)=>{
      setrawFETCH({...rawFETCH, SEARCH: Fnc.isNull(i) ? 'ALL' : i})
      sendRELOAD()
    }
    const handleEDIT =(i)=>{
      setdataGET(i)
      pageVIEW('record')
    }

    const handleDELETE =(i)=>{
      setdataGET(i)
      setopenDelete(true)
    }

    const dataDELETED =(i)=>{
      if(i == true){
        pageVIEW('new')
      }
    }
    

    const pageVIEW =(i,ii)=> {

        setdataVIEW(i)

        if(ii == 'add'){
          setdataGET('new')
        }

        if(i == 'new'){
          sendRELOAD()
        }

    }


    // =================== ++ FILTER ++ ===============================
    // ==================================================
    // =================== ++ UPSERT ++ ===============================


    const dataRETURN=(i)=>{
      setsendDATA(i)
    }
    


  return (
    <Container>

      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5} style={{marginTop:'20px'}}>
 
        <Typography variant="h3">{TheTitle}</Typography>
        {
          dataVIEW == 'new'
          ?

            <Button variant="outlined" 
                    sx={Cls.buttonClass('outlined','violet')} 
                    onClick={()=>(pageVIEW('record','add'))}
                    startIcon={<Icon icon="ic:round-plus" color='mediumpurple' />} >
              NEW
            </Button>

          : 
          dataVIEW == 'record' 
          ?

            <Button variant="outlined" 
                    sx={Cls.buttonClass('outlined','violet')} 
                    onClick={()=>(pageVIEW('new'))}
                    startIcon={<Icon icon="bi:clipboard-data" color='mediumpurple' />} >
               RECORDS
            </Button>

          : null
        }


      </Stack>


            {
              !dataLIST.load && dataVIEW == 'new' // if loading and no data
              ?

              <Loading_Skeletons type={'record_data'} />

              :

              dataLIST.load && dataVIEW == 'new' // if loaded & with data
              ?
              <>
              
              <Fade in={dataVIEW == 'new' ? true : false} timeout={500}>
                <Box component="section" sx={{ p: 2, border: '1px  grey' }}>
                  <Grid container spacing={{ xs: 2, md: 3 }} columns={{ xs: 12, sm: 12, md: 12 }} style={{marginTop:'-20px'}}>

                    <Grid  xs={1} sm={1} md={1} style={{marginBottom:'-20px'}}>

                      <Box sx={{ display: 'flex', justifyContent: 'flex-end', }}>
                        <IconButton>
                          <Icon icon="lets-icons:filter" color='mediumpurple' />
                        </IconButton>
                      </Box>

                    </Grid>

                    <Grid  xs={11} sm={11} md={5} style={{marginBottom:'-20px'}}>

                        <MenuOnSearch onSearching={handleSEARCH} onText={rawFETCH['SEARCH'] != 'ALL' ? rawFETCH['SEARCH'] : ''} />
                        
                    </Grid>

                    <Grid  xs={12} sm={6} md={6} style={{marginBottom:'-20px'}}>
                      <Box sx={{ display: 'flex', justifyContent: 'flex-end', }}>

                        <MenuOnDelete bySending={sendDATA} onReceiving={handleDELETE} />
                        &nbsp;
                        <MenuOnEdit bySending={sendDATA} onReceiving={handleEDIT} />

                      </Box>
                    </Grid>

                    <Grid  xs={12} sm={12} md={12}>
                      {
                        dataLIST.tally > 0
                        ?
                          <ViaTableRecord DATA={dataLIST.data} RETURN={dataRETURN}  />
                        :
                          <Alert variant="outlined" severity="info" width="100%" style={{marginTop:'30px', height:'100px', alignItems:'center'}}>
                            No record found..
                          </Alert>
                      }
                      
                    </Grid>

                  </Grid>
                </Box>
              </Fade>

              <ModalRecordDelete openDelete={openDelete} setopenDelete={setopenDelete} dataDelete={dataGET != 'new' ? dataGET : []} isDeleted={dataDELETED} />

              </>
              :

              dataLIST.load && dataVIEW == 'record' // if loaded & with data but on record view
              ?

                <UploadRecords ReData={dataGET} />

              : null
            }
              


    {
      //<pre>{JSON.stringify(rawFETCH,null,2)}</pre>
    }
    
    </Container>
  );
}


//cover, title, view, comment, share, author, createdAt, index
