import { useState, useEffect } from 'react';
import axios from 'axios';
import { Stack, Button, Container, Grid, Box, Typography, Card, Link, TextField, Divider, Alert  } from '@mui/material/';

import { UpsertData, UpsertLink, ImageLink } from 'src/hooks/upsert/upsert-data'

import * as Fnc from 'src/hooks/functions'
import * as Imp from 'src/hooks/importants'

import { imagetoRESIZE, imagetoUPLOAD } from 'src/hooks/imageupload'
import { Icon } from '@iconify/react';

// ----------------------------------------------------------------------

export default function Upsert({TheFor,TheTitle}) {


    const dataView  = localStorage.getItem('slk-dataview')

    const [data, setData] = useState({
                                      avatarpreview:       '',
                                      avatar:       'default_img_avatar.jpg',
                                      nickname:     '',
                                      ifnickname:   false,
                                      telegram:     '',
                                      email:        '',
                                      ifemail:      false,
                                      username:     '',
                                      ifusername:   false,
                                      password:     '',
                                      ifpassword:   false,
                                      repassword:   '',
                                      ifrepassword: false,
                                      })
    const [modified, setModified]       = useState(false)
    const [submitted, setSubmitted]     = useState('')
    const [submitting, setSubmitting]   = useState(false)

    const handleChange =(i,ii)=>{
      const val   = ii == 'username' ? Fnc.textUsername(i) : ii == 'password' || ii == 'repassword' ? Fnc.textPassword(i) : ii == 'nickname' ? Fnc.textName(i) : i
      if(ii == 'username' && data['avatarpreview'] != ''){
        setData({ ...data,  [ii]: val, avatar: val+'.jpg' })
      } else {
        setData({ ...data,  [ii]: val, })
      }
    }

    const handleCheck =()=>{
      const pass    = Fnc.checkPassword(data['password'])
      const email   = data['email'] !='' ? Fnc.checkEmail(Fnc.checkClean(data['email'])) : true;
      const uname   = Fnc.checkInput(data['username'],5)
      const nname   = Fnc.checkInput(Fnc.checkClean(data['nickname']),5)
      const repass  = data['password'] == data['repassword'] ? true : false

        setData({
          ...data,
          avatar:       data['avatarpreview'] != '' ? Fnc.checkClean(data['username'])+'.jpg' : 'default_img_avatar.jpg',
          nickname:     Fnc.checkClean(data['nickname']),
          email:        Fnc.checkClean(data['email']),
          telegram:     Fnc.checkClean(data['telegram']),
          username:     Fnc.checkClean(data['username']),
          password:     Fnc.checkClean(data['password']),
          ifnickname:   nname,
          ifemail:      email,
          ifusername:   uname,
          ifpassword:   pass,
          ifrepassword: repass,
        })
        setSubmitted('')
        setSubmitting(true)
      if( pass && email && uname && nname && repass ){
        handleSubmit()
      } else {
        setModified(true)
        setSubmitting(false)
      }

    }

    async function handleSubmit() {

      try {


        const response = await axios.post(UpsertLink('register'),data);

        const feed =  response.data;
        if(feed == 'ZERO'){
          setSubmitted('failed')
        } else if(feed['state'] == 'duplicate'){
          setSubmitted('duplicate')
        } else if(feed['state'] == 'added'){
          if(data['avatarpreview'] != ''){
            handleUpload(feed['feed'])
          }
          setSubmitted('success')
        }
        console.log(JSON.stringify(feed,null,2))
        setSubmitting(false)
      } catch (error) {
        alert("FAILED CSV ! "+error)
      }
    }

    const handleUpload = async (i) => {
 
      try {
        const newFile     = await imagetoUPLOAD(data['avatarpreview'],i);
        const formData = new FormData();
        formData.append('image', newFile);
        const response = await axios.post(ImageLink('user'), formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
      } catch (error) {
        console.error('Upload failed');
      }
    };

    // ==================================================
    // =================== ++ FILTER ++ ===============================

    const handleUploadImage = async (event) => {
      const file            = event.target.files[0];
      const imagePreview    = await imagetoRESIZE(file);
      setData({ ...data,  avatar:data['username']+'.jpg', avatarpreview: imagePreview })
      console.log(imagePreview);
    };
    
    useEffect(() => {

    }, [data]); 


  return (
<>

<Button variant="text" 
        size='small' 
        color="inherit" 
        onClick={()=>( window.history.go(-1)  )}
        startIcon={<Icon icon="eva:arrow-ios-back-fill" />} 
        style={{marginTop:'20px', marginLeft: '10px'}} >
          Go back 
</Button>

<Container >


<Stack alignItems="center" justifyContent="center" sx={{ height: 1 }} style={{marginTop:'10px'}}>
  <Card
    sx={{
      p: 5,
      width: 1,
      maxWidth: 750,
    }}
  >
    <Typography variant="h4">
      REGISTER
    </Typography>

    <Divider/>

    <Grid container spacing={{ xs: 2, md: 1 }} columns={{ xs: 12, sm: 12, md: 12 }} style={{marginTop:"20px"}}>
          <Grid item xs={12} sm={12} md={12} padding={'10px'}>
              <img src={data['avatarpreview']} alt="Preview" style={{height:'150px'}}/>
              <input type="file" accept='.jpeg, .jpg, .png' onChange={handleUploadImage} />
          </Grid>

          <Grid item xs={12} sm={12} md={12} padding={'10px'}>
              <TextField 
                  error ={modified && !data['ifnickname']  ? true : false}
                  name="text"
                  style={{minWidth: '50%'}}
                  required
                  label={modified && !data['ifnickname'] ? "Nickname (atleast 5 characters)" : "Nickname"}
                  value={data['nickname']}
                  onChange={(e) => handleChange(e.target.value,'nickname')} />
          </Grid>

    </Grid>

      <br></br>
      <Typography variant="div">Contacts:</Typography>
      <Divider/>

    <Grid container spacing={{ xs: 2, md: 1 }} columns={{ xs: 12, sm: 12, md: 12 }} style={{marginTop:"10px"}}>

          <Grid item xs={12} sm={6} md={6} padding={'10px'}>
              <TextField 
                  error ={modified && !data['ifemail']  ? true : false}
                  name="text"
                  fullWidth
                  label={modified && !data['ifemail'] && data['email'] != '' ? "Email (invalid format)" : "Email (optional)"}
                  value={data['email']}
                  onChange={(e) => handleChange(e.target.value,'email')} />
          </Grid>

          <Grid item xs={12} sm={6} md={6} padding={'10px'}>

              <TextField 
                  error ={false}
                  name="text"
                  fullWidth
                  label="Telegram (optional)"
                  value={data['telegram']}
                  onChange={(e) => handleChange(e.target.value,'telegram')} />

          </Grid>
    </Grid>

    <br></br>
    <Typography variant="div">Credentials:</Typography>
    <Divider/>

    <Grid container spacing={{ xs: 2, md: 1 }} columns={{ xs: 12, sm: 12, md: 12 }} style={{marginTop:"10px"}}>
          <Grid item xs={12} sm={12} md={12} padding={'10px'}>

              <TextField 
                  error ={modified && !data['ifusername']  ? true : false}
                  name="text"
                  style={{minWidth: '50%'}}
                  required
                  label={data['ifusername'] ? "Username" : "Username (atleast 5 characters)" }
                  value={data['username']}
                  onChange={(e) => handleChange(e.target.value,'username')} />

          </Grid>

          <Grid item xs={12} sm={12} md={6} padding={'10px'}>

              <TextField 
                  error ={modified && !data['ifpassword']  ? true : false}
                  name="text"
                  fullWidth
                  required
                  type='password'
                  label={"Password"}
                  value={data['password']}
                  onChange={(e) => handleChange(e.target.value,'password')} />
          </Grid>

          <Grid item xs={12} sm={12} md={6} padding={'10px'}>

                <TextField 
                    error ={modified && !data['ifrepassword']  ? true : false}
                    name="text"
                    fullWidth
                    required
                    type='password'
                    label={modified && !data['ifrepassword'] && data['repassword'] ? 'Password do not match' : 'Re-type Password'}
                    value={data['repassword']}
                    onChange={(e) => handleChange(e.target.value,'repassword')} />

          </Grid>
          { modified && !data['ifpassword'] ?
            <Grid item xs={12} sm={12} md={12}>
              <Alert severity="error">Password must atleast be 5 characters long with have 1 capital letter, 1 lowercase letter, 1 special character, and 1 numeric character.</Alert>

            </Grid>
              : 
              null
          }


      </Grid>

        {
          submitted == 'success' ?
            <>
              <Button variant='outlined' onClick={()=>window.location.href = '/login'}>Go to Login Page </Button>
              <Alert severity="success">Registration successful!</Alert>
            </>
          : submitted == 'duplicate' ?
          <>
            <Button variant='outlined' onClick={()=>handleCheck()}>Submit </Button>
            <Alert severity="warning">Username is already taken!</Alert>
          </>
          : submitted == 'failed' ?
          <>
            <Button variant='outlined' onClick={()=>handleCheck()}>Submit </Button>
            <Alert severity="error">Please try again!</Alert>
          </>
          : 
            submitting ? 
              <Button variant='outlined'>Submitting </Button>
              :
              <Button variant='outlined' onClick={()=>handleCheck()}>Submit </Button>
        }

  </Card>
</Stack>

</Container>
</>

  );
}

