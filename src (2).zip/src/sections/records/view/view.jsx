import { useState, useEffect } from 'react';

import Grid from '@mui/material/Unstable_Grid2';
import { Box,Stack,Container,Button,Typography,Alert } from '@mui/material';
import { Icon } from '@iconify/react';

import { RawRecords } from 'src/hooks/raw/';

import Loading_Skeletons from 'src/items/loaders/loadings'

import * as Data from 'src/hooks/data';
import { ViaTable, ViaList, ViaTableRecord } from 'src/items/fetched';
import { OnSortings, FormattingSorting } from 'src/items/sortingFilter';

import {AddingItem} from '../upsert/form';


// ----------------------------------------------------------------------

export default function Viewing({TheFor,TheTitle}) {

    const dataView  = localStorage.getItem('slk-dataview')

    const rawItems                          = RawRecords()

    const [listofDATA,  setlistofDATA]      = useState([])
    const [listofCOUNT, setlistofCOUNT]     = useState([])
    const [listofLOAD,  setlistofLOAD]      = useState(false)
    const [listFound,   setlistFound]       = useState(true)

    const [upsertofDATA,setupsertofDATA]    = useState([])
    
    useEffect(() => {

        setlistofDATA(rawItems.data)
        setlistofLOAD(rawItems.load)
        setlistofCOUNT(rawItems.tally)

    }, [rawItems.load == true]);



    // =================== ++ FILTER ++ ===============================
    // ==================================================
    // =================== ++ UPSERT ++ ===============================


    const ENLISTED_TABLE = [ 
                            { type:  'TEXT',    value: 'increment', header: 'ID', altimage:''},
                            { type:  'TEXT',    value: 'dateOpen', header: 'Openned', altimage:''},
                            { type:  'TEXT',    value: 'dateClose', header: 'Closed', altimage:''},
                            { type:  'TEXT',    value: 'playerID', header: 'ID', altimage:''},
                            { type:  'TEXT',    value: 'appName', header: 'Application', altimage:'accountID'},
                            { type:  'TEXT',    value: 'clubName', header: 'Club', altimage:''},
                            { type:  'PERCENT', value: 'clubPercent', header: 'Rake', altimage:''},
                            { type:  'TEXT',    value: 'uplineID', header: 'Upline', altimage:''},
                            { type:  'PERCENT', value: 'uplinePercent', header: 'Rake', altimage:''},
                            { type:  'USD',     value: 'fxUSD', header: 'USD', altimage:''},
                            { type:  'TEXT',    value: 'fxDate', header: 'FX Date', altimage:''},
                            { type:  'TEXT',    value: 'fxProvider', header: 'FX Provider', altimage:''},
                            { type:  'ACTION',  value: 'id', header: 'Action', altimage:''},
                          ]
    const listofUPSERT=(i)=>{
      setupsertofDATA({...i,AddType:TheFor})
    }


  return (
    <Container>

      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>

        <Typography variant="h4">{TheTitle}</Typography>

        <Button variant="contained" color="inherit" startIcon={<Icon icon="line-md:plus" />} >
            NEW 
        </Button>

      </Stack>

      <Grid container spacing={{ xs: 2, md: 3 }} columns={{ xs: 12, sm: 12, md: 12 }}>

          <Grid xs={12} sm={6} md={3}>
            <Box component="section" sx={{  }}>
            <Button variant="outlined">Go Back</Button>
            </Box>
          </Grid>

          <Grid xs={12} sm={8} md={7}>
            <Box component="section" sx={{ p: 2, border: '1px dashed grey' }}>
              
            </Box>
          </Grid>

          <Grid xs={12} sm={4} md={2}>
            <Box component="section" sx={{ p: 2, border: '1px dashed grey' }}>
              
            </Box>
          </Grid>

          <Grid xs={12} sm={12} md={12}>
            <Box component="section" sx={{ p: 2, border: '1px dashed grey' }}>
              {
               // <ViaTable DATA_TO={listofDATA} DATA_EN={ENLISTED_TABLE} DATA_RE={listofUPSERT} />
              }

              <ViaTableRecord DATA_TO={listofDATA} DATA_RE={listofUPSERT} />


            </Box>
          </Grid>

      </Grid>

    { listofLOAD == false ? 
        <Loading_Skeletons type={dataView} />
      :
      <>

        {listFound == true ?
          <>

          </>
        :
            <Grid xs={22} sm={22} md={22}>
              <Alert variant="outlined" severity="info" width="100%">
                  Nothing found..
              </Alert>
            </Grid>
        }

      </>
    }


    </Container>
  );
}


//cover, title, view, comment, share, author, createdAt, index
