import { useState, useEffect } from 'react';

import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Unstable_Grid2';
import Alert from '@mui/material/Alert';
import Typography from '@mui/material/Typography';


import { RawHistory } from 'src/hooks/raw/history';

import { Icon } from '@iconify/react';

import Loading_Skeletons from 'src/items/loaders/loadings'

import * as Data from 'src/hooks/data';

import { ViaCardUser, ViaTable, ViaList } from 'src/items/fetched';
import { OnSortings, FormattingSorting } from 'src/items/sortingFilter';

// ----------------------------------------------------------------------

export default function Viewing({TheFor,TheTitle}) {

    const dataView  = localStorage.getItem('slk-dataview')

    var [onToggle, setonToggle]           = useState(dataView);

    const [filterUser,setfilterUser]        = useState('ALL')
    const [filterGadget,setfilterGadget]    = useState('ALL')
    const [filterAction,setfilterAction]    = useState('ALL')
    const [filterOnFor,setfilterOnFor]      = useState('ALL')
    const [filterSort,setfilterSort]        = useState('DESC')
    const [filterSortBy,setfilterSortBy]    = useState('NONE')
    const [filterSearch,setfilterSearch]    = useState('')

    const rawItems                          = RawHistory(   TheFor,
                                                            filterUser ? filterUser : "ALL",
                                                            filterGadget ? filterGadget : "ALL",
                                                            filterAction ? filterAction : "ALL",
                                                            filterOnFor ? filterOnFor : "ALL",
                                                            filterSort ? filterSort : "DESC",
                                                            filterSortBy ? filterSortBy : "NONE",
                                                            filterSearch ? filterSearch : "",)
    


    const [listofDATA,setlistofDATA]        = useState([])
    const [listLoading,setlistLoading]      = useState(false)
    const [listFound,setlistFound]          = useState(true)

    const [upsertofData,setupsertofData]    = useState([])

    useEffect(() => {
        setlistofDATA(rawItems.data)
        setlistLoading(rawItems.load)
    }, [rawItems.load == true]);

    // ==================================================
    // =================== ++ FILTER ++ ===============================

    const onFilter_to =  [ ];

    const onSort_to =  [ 
                            //ITEMS,VALUE,IDD,OTHERS
                            [ FormattingSorting(Data.BY_HISTORY,"HISTORY",'value','label',"",false) ],
                          ];

    const onFilter_re =(i)=>{ }

    const onSort_re =(i)=>{

      if(i.arrange == 'ASC'){
        setfilterSort('ASC')
      } else {
        setfilterSort('DESC')
      }
      setfilterSortBy(i.by.x.idd ? i.by.x.idd : "NONE")
  }

  const onSearch_re =(i)=>{
    setfilterSearch(i)
  }

  const onToggle_re =(i)=>{
    localStorage.setItem('slk-dataview',i ? i : 'card')
    setonToggle(i)
  }

    // =================== ++ FILTER ++ ===============================
    // ==================================================
    // =================== ++ UPSERT ++ ===============================

    const ENLISTED_TABLE = [ 
                            { type:  'TEXT',    value: 'datetime', header: 'Date Stamp', altimage:''},
                            { type:  'TEXT',    value: 'timezone', header: 'Timezone', altimage:''},
                            { type:  'TEXT',    value: 'gadget', header: 'Gadget', altimage:''},
                            { type:  'TEXT',    value: 'userID', header: 'ID', altimage:''},
                            { type:  'TEXT',    value: 'userNickname', header: 'Nickname', altimage:''},
                            { type:  'TEXT',    value: 'userRole', header: 'Role', altimage:''},
                            { type:  'TEXT',    value: 'action', header: 'Action', altimage:''},
                            { type:  'TEXT',    value: 'dash', header: 'Dash', altimage:''},
                            { type:  'TEXT',    value: 'details', header: 'Details', altimage:''},
                          ]



    const listofUPSERT=(i)=>{
      setupsertofData({...i,AddType:TheFor})
    }
    
    // =================== ++ UPSERT ++ ===============================
    // ==================================================

    useEffect(() => {
      if(listLoading == true){
        if (!listofDATA.length) {
          setlistFound(false)
        } else {
          setlistFound(true)
        }                       
      }
    }, [listLoading]); 


  return (
    <Container>

      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>

        <Typography variant="h3">{TheTitle}</Typography>

      </Stack>

       <OnSortings  FILTER_TO={onFilter_to} 
                    FILTER_RE={onFilter_re} 
                    SORT_TO={onSort_to} 
                    SORT_RE={onSort_re}
                    SEARCH_RE={onSearch_re}
                    TOGGLE_RE={onToggle_re}
                    ITEMS='table' />



    { listLoading == false ? 
        <Loading_Skeletons type={'table'} />
      :
      <>

        {listFound == true ?
          <>

            {dataView == 'card' || dataView == 'table' || dataView == 'list' ? 
                <ViaTable DATA_TO={listofDATA} DATA_EN={ENLISTED_TABLE} DATA_RE={listofUPSERT} />
            : 
                null
            }
            
          </>
        :
            <Grid xs={22} sm={22} md={22}>
              <Alert variant="outlined" severity="info" width="100%">
                  Nothing found..
              </Alert>
            </Grid>
        }

      </>
    }








    </Container>
  );
}


//cover, title, view, comment, share, author, createdAt, index
