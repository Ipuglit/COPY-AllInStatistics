import useMediaQuery from '@mui/material/useMediaQuery';

export const goTo = (i) => {

  window.location.replace(i);
  window.location.href = i;

} 

export const isMobile = () => {

  const isTrue = useMediaQuery('(max-width:700px)');
  
  if(isTrue){
    return true
  } else {
    return false
  }

} 

export const downloadFile=(address,file)=>{
 
  const link          = document.createElement('a');
        link.href     = address+file;
        link.download = file;
        link.click();
        
}

export const intoString = (i) => {
  return String(i ? i : 'NONE').toUpperCase()

}

export const sortArray = (i,by) =>{

  const o = i.map((item) => item)
  .sort((a, b) => {
      if (a[by].toLowerCase() < b[by].toLowerCase()) {
          return -1;
      }
      if (a[by].toLowerCase() > b[by].toLowerCase()) {
          return 1;
      }
      return 0;
      });
  return o

} 

export const sortArrayDate = (i,by) =>{

  const sortedData = [...i].sort((a, b) => {
    const dateA = new Date(a[by]); // Convert strings to Date objects
    const dateB = new Date(b[by]);
    return dateB - dateA; // Sort descending for latest first
  });
  return sortedData;

} 

export const NotFound = (i) => {
    if(i == "NOTFOUND"){
        window.location.replace("/login"); 
        window.location.href = "/login";
    }
  }

export const numberWhole = (i) => {
    const num = i.replace(/[^0-9]/g, ''); // Replace any character that is not a digit with an empty string
    if (num.key == 'e' || num.key == 'E') {
      num.preventDefault();
    }
    return num
  }

export const numberHundred = (i) => {
  const num = i.replace(/[^0-9]/g, ''); // Replace any character that is not a digit with an empty string
  if (num.key == 'e' || num.key == 'E' || num.key == '.') {
    num.preventDefault();
  }
  if(i >=0 && i<=100 ){
    if (num.length > 1 && num.charAt(0) === '0') {
      return num.slice(1);
    } else {
      return num
    }
  } else {
      return 0
  }
}

export const numberOnly = (i) => {
  if(i != null || i != undefined){
      const regex = /^\d+$/;
      const num = regex.test(i) ? parseInt(i, 10) : 0;
      return num;
  } else {
      return 0;
  }
}

export const numberDecOnly = (i) => {
  if(i != null || i != undefined){
      const regex = /^[-+]?[0-9]+\.[^0-9]+$/;
      const num = regex.test(i) ? parseInt(i, 10) : 0;
      return num;
  } else {
      return 0;
  }
}



export const textName = (i) => {
  const val     = String(i).replace(/([^a-zA-Z0-9])\1+$/g, '');
  const allow   = val.replace(/[^a-zA-Z0-9.! @$&_+-.#]/g, "");
  return allow
};

export const textUsername = (i) => {
  const val     = String(i).replace(/([^a-zA-Z0-9])\1+$/g, '');
  const allow   = val.replace(/[^a-zA-Z0-9.!@$&_+-.#]/g, "");
  const non     = allow.replace(/\s/g, '');
  return non
};

export const textPassword = (i) => {
  const allow   = String(i).replace(/[^a-zA-Z0-9.!@$&_+-.#]/g, "");
  const non     = allow.replace(/\s/g, '');
  return non
};

export const checkPassword = (i) => {
  let regex = /^(?=.*\d)(?=.*[~`!@#$-_+.%^&()--+={}\[\]|\\:;"'<>,.?/_₹])(?=.*[a-z])(?=.*[A-Z]).{5,10}$/;
  return regex.test(i)
};

export const checkEmail = (i) => {
  let regex = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  return regex.test(i)
};

export const checkInput = (i,ii) => {
  if(i.length >= ii){
    return true;
  } else {
    return false;
  }
};

export const checkClean = (i) => {
  const allow   =  String(i).replace(/^\s+|\s+$/g, '');
  const non     = allow.replace(/\s+/g, ' '); 
  return non
};

export const firstTrail = (i) => {

  if (i.length >= 2 && i[0] === '0') {
    return i.slice(1); // Remove the first character
  } else {
      return i;
  }
};

export const Numb = (i) => {

  if(i != null || i != undefined){
    if (/^\d*\.?\d*$/.test(i)) {
      return firstTrail(i);
    }
  } else {
      return 0;
  }
};

export const numberNoTrailing = (i) => {
  const numberString = i.toString();
  if (numberString.includes('.') && /\d(?=\.)/.test(numberString)) {
    const formattedNumber = numberString.replace(/\.0+$/, '');
    return parseFloat(formattedNumber); // Convert back to number
  }
  return i;
}


export const NumForce = (i,e) => {
  const num = String(i).replace(/[^0-9.]/g, ''); // Replace any character that is not a number
  if ( num.includes('.') && /\d(?=\.)/.test(num) ) {

      const fix       = parseFloat(num).toFixed(e ? e : 2)
      const fixs      = fix.split('.')[0] + '.' + fix.split('.')[1].slice(0, e ? e : 2);
      const fixed     = fixs.replace(/\.0+$/, '');
      return parseFloat(fixed)

  } else {
      return num
  }
}


export const numberAdding= (i,e) => {

  const num = String(i).replace(/[^0-9.]/g, '');
  const fix = parseFloat(num).toFixed(e ? e : 2)
  return parseFloat(fix.split('.')[0] + '.' + fix.split('.')[1].slice(0, e ? e : 2))

}

export const numberDecimals = (i,e) => {
  const num = i.replace(/^[-+]?[0-9]+\.[^0-9]+$/, ''); // Replace any character that is not a digit with an empty string
  if (num.includes('.')) {
    return num.split('.')[0] + '.' + num.split('.')[1].slice(0, e ? e : 2);
  } else {
    return num
  }
}

export const wordNoSpace = (i) => {
    const num = i.replace(/[^a-zA-Z0-9!?#-_.]/g, ''); // Replace any character that is not a digit with an empty string
    return num
  }
export const wordTitled = (i) => {
  const num = i.replace(/[^a-zA-Z0-9!&. ]/g, '').replace(/\s{2,}/g, ' ').toUpperCase()
  return num
}

export const wordCapital = (i) => {
  return i.charAt(0).toUpperCase() + i.slice(1).toLowerCase();
};

export const wordLowerCase = (i) => {
  return i.toLowerCase();
};

export const wordNoSpaceCapital = (i) => {
  const num = i.replace(/[^a-zA-Z0-9!?#-_.]/g, ''); // Replace any character that is not a digit with an empty string
  if (num.key == 'e' || num.key == 'E') {
    num.preventDefault();
  }
  return num.toUpperCase();
}

export const dateSlashPlus = (i) => {

    const e = new Date(i);
    e.setDate(e.getDate() + 1);
    const year = e.getFullYear();
    const month = String(e.getMonth() + 1).padStart(2, '0'); // Month is zero-indexed
    const day = String(e.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;

}

export const dateSlash = (i) => {

  const e = new Date(i);
  e.setDate(e.getDate() + 1);
  const year = e.getFullYear();
  const month = String(e.getMonth() + 1).padStart(2, '0'); // Month is zero-indexed
  const day = String(e.getDate()).padStart(2, '0');
  return `${month}/${day}/${year}`;

}

export const dateDash = (i) => {

  const e = new Date(i);
  e.setDate(e.getDate());
  const year = e.getFullYear();
  const month = String(e.getMonth() + 1).padStart(2, '0'); // Month is zero-indexed
  const day = String(e.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;

}

export const dateLastSunday = (i) => {
const ddate = new Date(i);
const numDay = ddate.getDay();
const Sun = new Date(ddate);
Sun.setDate(ddate.getDate() - numDay);
const sunday = Sun.toDateString()
return dateDash(sunday);
}

export const dateWord = (i) => {
  const n = new Date(i)
  const o = { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' };
  const w = n.toLocaleDateString('en-US', o);
  return w;
}

export const addNumbers = (arr) => {
  let sum = 0;
  for (const number of arr) {
    sum += parseFloat(number);
  }
  return NumForce(sum)
}

export const equalAutoComplete = (i, value)=>{
  if(value != null && value != 0 && value != ''){
    const ret = String(i.value).toLowerCase() == String(value).toLowerCase();
    return ret
  } else {
    return false
  }

}

export const isNull =(i,ii)=>{
  if( (i == '' || i == null || i == undefined || i == "" || (ii == 'Num' ? i == 0 : null))){
    return true
  } else {
    return false
  }
}

export const JSONChecking =(u,uu,uuu,rawClubs,rawAccounts,rawUplines)=>{

  if(u != 'ERR'){

      const ArrayJSON = uu.map((rw) => {
          const e = {};
          for (let i = 0; i < rw.length; i++) {
          e[u[i]] = rw[i];
          }
          return e;
      });

      const arrClubs = [{

      }]

      const fillClubs =(VAL)=>{

          const x = rawClubs.find((e) => e.idd == VAL || e.name == VAL);
          if(x){
            console.log('YYY '+VAL)
              return {
                        CLUB:           x.name,
                        CLUBIDD:        x.idd,
                        CLUBSUB:        'SAME',
                        CLUBPERCENT:    x.percent,
                        APPID:          x.appID,
                        APPNAME:        x.appName,
                      }
                      
          } else {
            console.log('XXX '+VAL)
              return {
                        CLUB:           VAL,
                        CLUBIDD:        '0',
                        CLUBSUB:        'NONE',
                        CLUBPERCENT:    '0',
                        APPID:          '0',
                        APPNAME:        '',
                      }
          }
      }

      const fillPlayers =(VAL,APP,CLUB)=>{
          const xp = rawAccounts.find((e) => ( e.accountID == VAL ) );

          if(xp){
            if( xp.appID == APP ){
              console.log('AAA '+VAL+' '+APP+' '+CLUB)
              return {
                PLAYERID:       xp.accountID,
                PLAYERNAME:     xp.accountNickname,
                PLAYERSTATUS:   xp.statusLabel,
                PLAYERSUB:      'SAME',
              }

            } else {
              console.log('BBB '+VAL+' '+APP+' '+CLUB)
              return {
                        PLAYERID:       xp.accountID,
                        PLAYERNAME:     xp.accountNickname,
                        PLAYERSTATUS:   xp.statusLabel,
                        PLAYERSUB:      'WRONG',
                      }
            }
          } else {
            console.log('CCC '+VAL+' '+APP+' '+CLUB)
              return {
                        PLAYERID:       VAL,
                        PLAYERNAME:     '',
                        PLAYERSTATUS:   '',
                        PLAYERSUB:      'NEW',
                      }
          }
      }


      const fillUplines =(VAL,APP,CLUB)=>{

        const x = rawUplines.find((e) => ( e.playerID == VAL && e.clubIDD == CLUB ) );

        if(x){

          if( x.appID == APP ){
            return {
                        UPLINEID:       x.uplineID,
                        UPLINENAME:     x.uplineNickname,
                        UPLINESTATUS:   x.uplineStatusLabel,
                        UPLINEPERCENT:  x.percentage,
                        UPLINESUB:      'SAME',
                    }

          } else {
            return {
                        UPLINEID:       '0',
                        UPLINENAME:     '',
                        UPLINESTATUS:   '',
                        UPLINEPERCENT:  '0',
                        UPLINESUB:      'WRONG',
                    }
          }
        } else {
            return {
                        UPLINEID:       '0',
                        UPLINENAME:     '',
                        UPLINESTATUS:   '',
                        UPLINEPERCENT:  '0',
                        UPLINESUB:      'NONE',
                    }
        }
    }

      if(uuu == 'SHORT'){

        const newArray = ArrayJSON.map( ii => {

          const iClub = ii['CLUB'] ? fillClubs(ii['CLUB']) : fillClubs(ii['CLUB']);
          const iPlayers = ii['PLAYERID'] ? fillPlayers(ii['PLAYERID'],iClub.APPID,iClub.CLUBIDD) : fillPlayers(ii['PLAYERID'],iClub.APPID,iClub.CLUBIDD);
          const iUplines = ii['PLAYERID'] ? fillUplines(ii['PLAYERID'],iClub.APPID,iClub.CLUBIDD) : fillUplines(ii['PLAYERID'],iClub.APPID,iClub.CLUBIDD);
           return {
                      ...ii,
                      CLUB:             iClub.CLUB,
                      CLUBIDD:          iClub.CLUBIDD,
                      CLUBID:           NumForce(ii['CLUBID']),
                      CLUBSUB:          iClub.CLUBSUB,
                      CLUBPERCENT:      iClub.CLUBPERCENT,
                      APPID:            iClub.APPID,
                      APPNAME:          iClub.APPNAME,
                      PLAYERNAME:       iPlayers.PLAYERNAME,
                      PLAYERSTATUS:     iPlayers.PLAYERSTATUS,
                      PLAYERSUB:        iPlayers.PLAYERSUB,
                      UPLINEID:         iUplines.UPLINEID,
                      UPLINENAME:       iUplines.UPLINENAME,
                      UPLINESTATUS:     iUplines.UPLINESTATUS,
                      UPLINEPERCENT:    iUplines.UPLINEPERCENT,
                      UPLINESUB:        iUplines.UPLINESUB,
                      FXCURRENCY:       'USD',
                      FXUSD:            1,
                      FXDATE:           '',
                      FXPROVIDER:       '',
                      DATECLOSED :      dateSlashPlus(ii['DATECLOSED']),
                      BONUS_6:          0,
                      BONUS_FLH:        0,
                      BONUS_FLOHI:      0,
                      BONUS_FLOHILO:    0,
                      BONUS_MIXED:      0,
                      BONUS_MTT:        0,
                      BONUS_NLH:        0,
                      BONUS_OFC:        0,
                      BONUS_OTHERBONUS: NumForce(ii['BONUS_TOTAL']),
                      BONUS_PLOHI:      0,
                      BONUS_PLOHILO:    0,
                      BONUS_SNG:        0,
                      BONUS_SPIN:       0,
                      WINLOSS_6:        0,
                      WINLOSS_FLH:      0,
                      WINLOSS_FLOHI:    0,
                      WINLOSS_FLOHILO:  0,
                      WINLOSS_MIXED:    0,
                      WINLOSS_MTT:      0,
                      WINLOSS_NLH:      0,
                      WINLOSS_OFC:      0,
                      WINLOSS_OTHERWINLOSS: NumForce(ii['WINLOSS_TOTAL']),
                      WINLOSS_PLOHI:    0,
                      WINLOSS_PLOHILO:  0,
                      WINLOSS_SNG:      0,
                      WINLOSS_SPIN:     0,
                      WINLOSS_TOTAL:    NumForce(ii['WINLOSS_TOTAL']),
                      BONUS_TOTAL:      NumForce(ii['BONUS_TOTAL']),
          }

        });

        return newArray

      } else if(uuu == 'LONG'){


        const newArray = ArrayJSON.map( ii => {

           const iClub = ii['CLUB'] ? fillClubs(ii['CLUB']) : fillClubs(ii['CLUB']);
           const iPlayers = ii['PLAYERID'] ? fillPlayers(ii['PLAYERID'],iClub.APPID,iClub.CLUBIDD) : fillPlayers(ii['PLAYERID'],iClub.APPID,iClub.CLUBIDD);
           const iUplines = ii['PLAYERID'] ? fillUplines(ii['PLAYERID'],iClub.APPID,iClub.CLUBIDD) : fillUplines(ii['PLAYERID'],iClub.APPID,iClub.CLUBIDD);
            return {
                      ...ii,
                      CLUB:             iClub.CLUB,
                      CLUBIDD:          iClub.CLUBIDD,
                      CLUBID:           NumForce(ii['CLUBID']),
                      CLUBPERCENT:      iClub.CLUBPERCENT,
                      CLUBSUB:          iClub.CLUBSUB,
                      APPID:            iClub.APPID,
                      APPNAME:          iClub.APPNAME,
                      PLAYERNAME:       iPlayers.PLAYERNAME,
                      PLAYERSTATUS:     iPlayers.PLAYERSTATUS,
                      PLAYERSUB:        iPlayers.PLAYERSUB,
                      UPLINEID:         iUplines.UPLINEID,
                      UPLINENAME:       iUplines.UPLINENAME,
                      UPLINESTATUS:     iUplines.UPLINESTATUS,
                      UPLINEPERCENT:    iUplines.UPLINEPERCENT,
                      UPLINESUB:        iUplines.UPLINESUB,
                      FXCURRENCY:       'USD',
                      FXUSD:            1,
                      FXDATE:           '',
                      FXPROVIDER:       '',
                      DATECLOSED :      dateSlashPlus(ii['DATECLOSED']),
                      BONUS_6:          NumForce(ii['BONUS_6']),
                      BONUS_FLH:        NumForce(ii['BONUS_FLH']),
                      BONUS_FLOHI:      NumForce(ii['BONUS_FLOHI']),
                      BONUS_FLOHILO:    NumForce(ii['BONUS_FLOHILO']),
                      BONUS_MIXED:      NumForce(ii['BONUS_MIXED']),
                      BONUS_MTT:        NumForce(ii['BONUS_MTT']),
                      BONUS_NLH:        NumForce(ii['BONUS_NLH']),
                      BONUS_OFC:        NumForce(ii['BONUS_OFC']),
                      BONUS_PLOHI:      NumForce(ii['BONUS_PLOHI']),
                      BONUS_PLOHILO:    NumForce(ii['BONUS_PLOHILO']),
                      BONUS_SNG:        NumForce(ii['BONUS_SNG']),
                      BONUS_SPIN:       NumForce(ii['BONUS_SPIN']),
                      BONUS_OTHERBONUS: NumForce(ii['BONUS_OTHERBONUS']),
                      WINLOSS_6:        NumForce(ii['WINLOSS_6']),
                      WINLOSS_FLH:      NumForce(ii['WINLOSS_FLH']),
                      WINLOSS_FLOHI:    NumForce(ii['WINLOSS_FLOHI']),
                      WINLOSS_FLOHILO:  NumForce(ii['WINLOSS_FLOHILO']),
                      WINLOSS_MIXED:    NumForce(ii['WINLOSS_MIXED']),
                      WINLOSS_MTT:      NumForce(ii['WINLOSS_MTT']),
                      WINLOSS_NLH:      NumForce(ii['WINLOSS_NLH']),
                      WINLOSS_OFC:      NumForce(ii['WINLOSS_OFC']),
                      WINLOSS_PLOHI:    NumForce(ii['WINLOSS_PLOHI']),
                      WINLOSS_PLOHILO:  NumForce(ii['WINLOSS_PLOHILO']),
                      WINLOSS_SNG:      NumForce(ii['WINLOSS_SNG']),
                      WINLOSS_SPIN:     NumForce(ii['WINLOSS_SPIN']),
                      WINLOSS_OTHERWINLOSS: NumForce(ii['WINLOSS_OTHERWINLOSS']),
                      WINLOSS_TOTAL:    addNumbers([NumForce(ii['WINLOSS_NLH']),NumForce(ii['WINLOSS_FLH']),NumForce(ii['WINLOSS_6']),NumForce(ii['WINLOSS_PLOHI']),NumForce(ii['WINLOSS_PLOHILO']),NumForce(ii['WINLOSS_FLOHI']),NumForce(ii['WINLOSS_FLOHILO']),NumForce(ii['WINLOSS_MIXED']),NumForce(ii['WINLOSS_OFC']),NumForce(ii['WINLOSS_MTT']),NumForce(ii['WINLOSS_SNG']),NumForce(ii['WINLOSS_SPIN']),NumForce(ii['WINLOSS_OTHERWINLOSS'])]),
                      BONUS_TOTAL:      addNumbers([NumForce(ii['BONUS_NLH']),NumForce(ii['BONUS_FLH']),NumForce(ii['BONUS_6']),NumForce(ii['BONUS_PLOHI']),NumForce(ii['BONUS_PLOHILO']),NumForce(ii['BONUS_FLOHI']),NumForce(ii['BONUS_FLOHILO']),NumForce(ii['BONUS_MIXED']),NumForce(ii['BONUS_OFC']),NumForce(ii['BONUS_MTT']),NumForce(ii['BONUS_SNG']),NumForce(ii['BONUS_SPIN']),NumForce(ii['BONUS_OTHERBONUS'])]),
                    }

        });

        return newArray
      }

  } else {
        return []
  }

}