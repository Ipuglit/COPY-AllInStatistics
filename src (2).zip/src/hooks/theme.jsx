export const input_violet = {
                                "& .MuiOutlinedInput-input": { color: 'gray' }, // Change text color
                                "& .MuiOutlinedInput-notchedOutline": {
                                borderColor: 'gray', // Change border color on focus
                                },
                                "& .Mui-focused .MuiOutlinedInput-notchedOutline": {
                                borderColor: '#EE82EE', // Change border color on selection
                                },
                            }