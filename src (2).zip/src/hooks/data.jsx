import { Icon } from '@iconify/react';

export const BY_STATUS = [
  { id: 0, idd: 0, value: 'ALL', label: 'All', others: "", what: "STATUS" },
  { id: 1, idd: 1, value: 'ACTIVE', label: 'Active', others: "", what: "STATUS" },
  { id: 2, idd: 2, value: 'PENDING', label: 'Pending', others: "", what: "STATUS" },
  { id: 3, idd: 3, value: 'ACTIVEPENDING', label: 'Active & Pending', others: "", what: "STATUS" },
  { id: 4, idd: 4, value: 'DISABLED', label: 'Disabled', others: "", what: "STATUS" },
];
 
export const BY_ORDER = [
  { id: 0, value: 'ASC', label: <Icon icon="bxs:up-arrow"/> },
  { id: 1, value: 'DESC', label: <Icon icon="bxs:down-arrow"/> },
];

// ====================== +++ ITEMS +++ ====================================

export const BY_ACCOUNTS = [
  { id: 0,idd: 0, value: 'NONE', label: 'ID', others: "", what: "ACCOUNTS" },
  { id: 1,idd: 1, value: 'app.name', label: 'Application', others: "", what: "ACCOUNTS" },
  { id: 2,idd: 2, value: 'a.accountID', label: 'Account ID', others: "", what: "ACCOUNTS" },
  { id: 3,idd: 3, value: 'a.accountNickname', label: 'Nickname', others: "", what: "ACCOUNTS" },
  { id: 4,idd: 4, value: 'a.accountRole', label: 'Role', others: "", what: "ACCOUNTS" },
  { id: 5,idd: 5, value: 'a.status', label: 'Status', others: "", what: "ACCOUNTS" },
];

export const BY_UPLINES = [
  { id: 0,idd: 0, value: 'NONE', label: 'ID', others: "", what: "UPLINES" },
  { id: 1,idd: 1, value: 'app.name', label: 'Application', others: "", what: "UPLINES" },
  { id: 2,idd: 2, value: 'up.clubID', label: 'Club ID', others: "", what: "UPLINES" },
  { id: 3,idd: 3, value: 'c.name', label: 'Club', others: "", what: "UPLINES" },
  { id: 4,idd: 4, value: 'up.downlineID', label: 'Player ID', others: "", what: "UPLINES" },
  { id: 5,idd: 5, value: 'up.uplineID', label: 'Upline ID', others: "", what: "UPLINES" },
  { id: 6,idd: 6, value: '(SELECT aa.accountNickname FROM accounts AS aa WHERE aa.accountID = up.downlineID)', label: 'Player Nickname', others: "", what: "UPLINES" },
  { id: 7,idd: 7, value: '(SELECT aa.accountNickname FROM accounts AS aa WHERE aa.accountID = up.uplineID)', label: 'Upline Nickname', others: "", what: "UPLINES" },
  { id: 8,idd: 8, value: 'up.percentage', label: 'Percentage', others: "", what: "UPLINES" },
  { id: 9,idd: 9, value: 'up.status', label: 'Status', others: "", what: "UPLINES" },
];

export const BY_HISTORY = [
  { id: 0,idd: 0, value: 'NONE', label: 'ID', others: "", what: "HISTORY" },
  { id: 1,idd: 1, value: 'u.nickname', label: 'Nickname', others: "", what: "HISTORY" },
  { id: 2,idd: 2, value: 'r.name', label: 'Role', others: "", what: "HISTORY" },
  { id: 3,idd: 3, value: 'h.datetime', label: 'Date stamp', others: "", what: "HISTORY" },
  { id: 4,idd: 4, value: 'h.gadget', label: 'Gadget', others: "", what: "HISTORY" },
  { id: 4,idd: 4, value: 'h.timezone', label: 'Timezone', others: "", what: "HISTORY" },
  { id: 5,idd: 5, value: 'h.action', label: 'Action', others: "", what: "HISTORY" },
  { id: 5,idd: 5, value: 'h.for', label: 'For', others: "", what: "HISTORY" },
];

export const BY_FXAPPLY = [
  { id: 0,idd: 0, value: 'This', label: 'This item'},
  { id: 1,idd: 1, value: 'Clubs', label: 'To all same clubs'},
  { id: 2,idd: 2, value: 'Applications', label: 'To all same apps'},
  { id: 3,idd: 3, value: 'Players', label: 'To all same player' },
  { id: 4,idd: 4, value: 'Date Closed', label: 'To all same date'},
  { id: 5,idd: 5, value: 'All', label: 'To all'},
];

