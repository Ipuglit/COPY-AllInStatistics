
export const inputDate =(base,label)=>{
    return {      
                    container: {
                    display: 'flex',
                    flexWrap: 'wrap',
                    },
                    textField: {
                    marginLeft: 1,
                    marginRight: 1,
                    width: 150,
                    },
                    '& .MuiInputLabel-root': { // Target label
                        fontSize: label+'px',
                        fontWeight: 'bold', // Set label weight
                        
                    },
                    '& .MuiInputBase-input': { 
                    fontSize: base+'px', 
                    //color: 'purple'
                    },
                    '& .MuiOutlinedInput-root': {
                        '&.Mui-focused fieldset': {
                          borderColor: 'violet', // change this value to whatever color you need
                        },
                    },
            }

}
                
export const inputResizing =(base,label,mbase,mlabel,labelcolor,centered)=>{
    return {
                    '& .MuiInputLabel-root': { // Target label
                        fontSize: label+'px',
                        fontWeight: 'bold', // Set label weight
                        color: labelcolor ? labelcolor : '',
                        '@media (max-width: 600px)': { // Media query for mobile screens
                            fontSize: mlabel+'px', // Font size for mobile
                          },
                    },
                        '& .MuiInputBase-input': { 
                        fontSize: base+'px', 
                        textAlign: centered ? centered : '',
                        '@media (max-width: 600px)': { // Media query for mobile screens
                            fontSize: mbase+'px', // Font size for mobile
                        },
                    },
                        '& .MuiOutlinedInput-root': {
                        '&.Mui-focused fieldset': {
                          borderColor: 'violet', // change this value to whatever color you need
                        },
                    },
                }

}

export const inputFormat =(base,label,labelcolor,centered)=>{
    return {
                    '& .MuiInputLabel-root': { // Target label
                        fontSize: label+'px',
                        fontWeight: 'bold', // Set label weight
                        color: labelcolor ? labelcolor : ''
                    },
                    '& .MuiInputBase-input': { 
                    fontSize: base+'px', 
                    textAlign: centered ? centered : '',
                    },
                    '& .MuiOutlinedInput-root': {
                        fontSize: label+'px',
                        '&.Mui-focused fieldset': {
                          borderColor: 'violet', // change this value to whatever color you need

                        },
                    },
                    '& label.Mui-focused': {
                        color: 'violet'
                      },
                }

}

export const labelResizing =(pc,mob,pcwid,mobwid)=>{
    return {
        fontSize: pc ? pc+'px' : '',
        minWidth: pcwid ? pcwid+'px' : '',
        '@media (max-width: 700px)': { // On Mobile
        fontSize: mob ? mob+'px' : '',
        minWidth: mobwid ? mobwid+'px' : '',
        },
    }
}