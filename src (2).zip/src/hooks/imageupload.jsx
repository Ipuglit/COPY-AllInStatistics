import Papa from 'papaparse'
import Resizer from "react-image-file-resizer";

export const imagetoRESIZE = async (file) => {
    return new Promise((resolve) => {
      Resizer.imageFileResizer(
        file,
        350, // maxWidth
        350, // maxHeight
        "JPEG", // compressFormat
        100, // quality
        0, // rotation
        (uri) => {
          resolve(uri);
        },
        "base64" // outputType
      );
    });
  };

export const imagetoUPLOAD = async (IMG,TITLE) =>{

          const byteString = atob(IMG.split(',')[1]);
          const mimeType = IMG.split(',')[0].split(':')[1].split(';')[0];
          const arrayBuffer = new ArrayBuffer(byteString.length);
          const intArray = new Uint8Array(arrayBuffer);
          
          for (let i = 0; i < byteString.length; i++) {
            intArray[i] = byteString.charCodeAt(i);
          }
  
          const blob = new Blob([arrayBuffer], { type: mimeType });
          
          const originalFileName = TITLE+'.jpg'; // Adjust filename as needed
          const originalFileType = blob.type; // Retrieve type from Blob
      
          const newFile = new File([blob], originalFileName, { type: originalFileType });
  
          return newFile;

}