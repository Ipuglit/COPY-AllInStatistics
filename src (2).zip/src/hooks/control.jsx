import { useEffect, useState } from 'react';

export const GoTo = (User,Way) => {

        const Move  = Way ? true : false;
        const Upper = ['7','8'];
      
        if(Move){
            var userRole     = User['roleID']
            var Apps         = Upper.includes(userRole) ? true :  Way['apps'] == 'ALLOW'        || Way['apps']      == 'VIEW' ? true : false
            var Clubs        = Upper.includes(userRole) ? true :  Way['clubs'] == 'ALLOW'       || Way['clubs']     == 'VIEW' ? true : false
            var Users        = Upper.includes(userRole) ? true :  Way['users'] == 'ALLOW'       || Way['users']     == 'VIEW' ? true : false
            var Acct         = Upper.includes(userRole) ? true :  Way['accounts'] == 'ALLOW'    || Way['accounts']  == 'VIEW' ? true : false
            var Unions       = Upper.includes(userRole) ? true :  Way['unions'] == 'ALLOW'      || Way['unions']    == 'VIEW' ? true : false
            var Uplines      = Upper.includes(userRole) ? true :  Way['uplines'] == 'ALLOW'     || Way['uplines']   == 'VIEW' ? true : false
            var Records      = Upper.includes(userRole) ? true :  Way['records'] == 'ALLOW'     || Way['records']   == 'VIEW' ? true : false
            var CSVUp        = Upper.includes(userRole) ? true :  Way['csvup'] == 'ALLOW'     ? true : false
            var Rates        = Upper.includes(userRole) ? true :  Way['fxrates']   == 'VIEW'  ? true : false
            var History      = Upper.includes(userRole) ? true :  Way['history']   == 'VIEW'  ? true : false
            var Notifs       = Upper.includes(userRole) ? true :  Way['notification'] == 'ALLOW' || Way['notification'] == 'VIEW' ? true : false
        }

return {
        userRole:       userRole,
        Apps:           Apps,
        Clubs:          Clubs,
        Users:          Users,
        Acct:           Acct,
        Unions:         Unions,
        Uplines:        Uplines,
        Records:        Records,
        CSVUp:          CSVUp,
        Rates:          Rates,
        History:        History,
        Notifs:         Notifs,
    }

}
