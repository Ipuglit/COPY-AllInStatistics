export const TimeZoned = Intl.DateTimeFormat().resolvedOptions().timeZone;

const LocIP                                 = import.meta.env.VITE_GO_LOC

export const Fetch = {
                        users:              LocIP+import.meta.env.VITE_GET_USERS,
                        myaccounts:         LocIP+import.meta.env.VITE_GET_MYACCOUNTS,
                        accounts:           LocIP+import.meta.env.VITE_GET_ACCOUNTS,
                        accountsupline:     LocIP+import.meta.env.VITE_GET_ACCOUNTS_UPLINE,
                        applications:       LocIP+import.meta.env.VITE_GET_APPS,
                        myclubs:            LocIP+import.meta.env.VITE_GET_MYCLUBS,
                        clubs:              LocIP+import.meta.env.VITE_GET_CLUBS,
                        history:            LocIP+import.meta.env.VITE_GET_HISTORY,
                        myhistory:          LocIP+import.meta.env.VITE_GET_MYHISTORY,
                        notification:       LocIP+import.meta.env.VITE_GET_NOTIFICATION,
                        notification_count: LocIP+import.meta.env.VITE_GET_NOTIFICATION_COUNT,
                        authenticate:       LocIP+import.meta.env.VITE_GET_AUTHENTICATE,
                        profile:            LocIP+import.meta.env.VITE_GET_PROFILE,
                        images:             LocIP+import.meta.env.VITE_GET_IMAGES,
                        unions:             LocIP+import.meta.env.VITE_GET_UNIONS,
                        company:            LocIP+import.meta.env.VITE_GET_COMPANY,
                        roles:              LocIP+import.meta.env.VITE_GET_ROLES,
                        roleusers:          LocIP+import.meta.env.VITE_GET_ROLEUSERS,
                        uplines:            LocIP+import.meta.env.VITE_GET_UPLINES,
                        uplines2:           LocIP+import.meta.env.VITE_GET_UPLINES2,
                        fxrates:            LocIP+import.meta.env.VITE_GET_FXRATES,
                        exchangerates:      LocIP+import.meta.env.VITE_GET_EXCHANGERATE,
                        records:            LocIP+import.meta.env.VITE_GET_RECORDS,
                    };

                    
export const URL = {
                        fxusd1:             LocIP+import.meta.env.VITE_URL_FXUSD1,
                        fxusd2:             LocIP+import.meta.env.VITE_URL_FXUSD2,
                        fxusd3:             LocIP+import.meta.env.VITE_URL_FXUSD3,
                    };

export const API = {
                        fxusd1API:          LocIP+import.meta.env.VITE_API_FXUSD1,
                    };

export const Upsert = {
                        login:              LocIP+import.meta.env.VITE_GO_LOGIN,
                        users:              LocIP+import.meta.env.VITE_UPSERT_USERS,
                        accounts:           LocIP+import.meta.env.VITE_UPSERT_ACCOUNTS,
                        applications:       LocIP+import.meta.env.VITE_UPSERT_APPS,
                        clubs:              LocIP+import.meta.env.VITE_UPSERT_CLUBS,
                        unions:             LocIP+import.meta.env.VITE_UPSERT_UNIONS,
                        uplines:            LocIP+import.meta.env.VITE_UPSERT_UPLINES,
                        profile:            LocIP+import.meta.env.VITE_UPSERT_PROFILE,
                        exchangerate:       LocIP+import.meta.env.VITE_UPSERT_EXCHANGERATE,
                        records:            LocIP+import.meta.env.VITE_UPSERT_RECORDS,
                    };

export const Upserts = {
                        login:              LocIP+import.meta.env.VITE_GO_LOGIN,
                        users:              LocIP+import.meta.env.VITE_UPSERTS_USERS,
                        accounts:           LocIP+import.meta.env.VITE_UPSERTS_ACCOUNTS,
                        applications:       LocIP+import.meta.env.VITE_UPSERTS_APPS,
                        clubs:              LocIP+import.meta.env.VITE_UPSERTS_CLUBS,
                        unions:             LocIP+import.meta.env.VITE_UPSERTS_UNIONS,
                        uplines:            LocIP+import.meta.env.VITE_UPSERTS_UPLINES,
                        profile:            LocIP+import.meta.env.VITE_UPSERTS_PROFILE,
                        exchangerate:       LocIP+import.meta.env.VITE_UPSERTS_EXCHANGERATE,
                        csvupload:          LocIP+import.meta.env.VITE_UPSERTS_CSVUPLOAD,
                        register:           LocIP+import.meta.env.VITE_UPSERTS_REGISTER,

                    };

export const Uploads = {
                        users:              LocIP+import.meta.env.VITE_UPLOADS_USERS,
                        accounts:           LocIP+import.meta.env.VITE_UPLOADS_ACCOUNTS,
                        applications:       LocIP+import.meta.env.VITE_UPLOADS_APPS,
                        clubs:              LocIP+import.meta.env.VITE_UPLOADS_CLUBS,
                        unions:             LocIP+import.meta.env.VITE_UPLOADS_UNIONS,
                        uplines:            LocIP+import.meta.env.VITE_UPLOADS_UPLINES,
                        profile:            LocIP+import.meta.env.VITE_UPLOADS_PROFILE,
                        exchangerate:       LocIP+import.meta.env.VITE_UPLOADS_EXCHANGERATE,
                        images:             LocIP+import.meta.env.VITE_UPLOADS_IMAGES,
                        records:            LocIP+import.meta.env.VITE_UPLOADS_RECORDS,
                        register:           LocIP+import.meta.env.VITE_UPLOADS_REGISTER,
                    };

export const Images = {
                        user:               LocIP+import.meta.env.VITE_IMAGE_AVATAR,
                        club:               LocIP+import.meta.env.VITE_IMAGE_CLUB,
                        application:        LocIP+import.meta.env.VITE_IMAGE_APP,
                    };
                    
export const Path = {
                        icons:              "/images/icons/",
                        apps:               "/images/apps/",
                        clubs:              "/images/clubs/",
                        avatars:            "/images/avatars/",
                        logo:               "/images/logo/",
                        pictures:           "/images/pictures/"
                    };

export const unionType = [
                        {
                          key: 'PRIVATE',
                          text: 'PRIVATE',
                          value: 'PRIVATE',
                        },
                        {
                          key: 'PUBLIC',
                          text: 'PUBLIC',
                          value: 'PUBLIC',
                        },
                        {
                          key: 'UNION',
                          text: 'UNION',
                          value: 'UNION',
                        },
                      ]

export function LogOut(){
    window.location.replace("/login"); 
    window.location.href = "/login";
}


