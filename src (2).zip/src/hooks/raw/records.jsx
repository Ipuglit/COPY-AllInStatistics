import { useLayoutEffect, useState } from 'react';
import axios from 'axios';
import * as Imp from '../importants'
import * as Fnc from '../functions'

export default function RawRecords(aa,bb,cc,dd,ee,ff,gg,hh,ii,jj,kk) {

    const Token = JSON.parse( localStorage.getItem('slk-token') );

    const [load, setLoad]       = useState(false)
    const [data, setData]       = useState([])
    const [tally, setTally]     = useState(0)

    const Auth = {
                        A:              Token.id,
                        B:              Token.token,
                        C:              Token.gadget,
                        D:              Imp.TimeZoned,
                        FOR:            aa ? aa : "ALL",
                        STATUS:         bb ? bb : 'ALL',
                        SORTBY:         cc ? cc : 'ALL',
                        SORT:           dd ? dd : 'DESC',
                        LIMIT:          ee ? ee : 200,
                        SEARCH:         ff ? ff : 'ALL',
                        DATE:           gg ? gg : 'ALL',
                        APP:            hh ? hh : 'ALL',
                        CLUB:           ii ? ii : 'ALL',
                        PLAYER:         jj ? jj : 'ALL',
                        UPLINE:         kk ? kk : 'ALL',
                    }; 

    async function fetching() {
        setLoad(false)
        try {

            const response = await axios.post(Imp.Fetch['records'], Auth);

            if(response.data.Values == "NOTFOUND" || response.data.Values == "ZERO" ){
                Fnc.NotFound()
                setData([]);
                setTally(0)
                setLoad(true)
            } else {
                var arrValue = response.data.Values


                setData(arrValue);
                setTally(response.data.Count)
                setLoad(true)
            }
            console.log(JSON.stringify(response.data.Values,null,2))
            console.log("Records items fetched...")

        } catch (error) {
            console.error("Error fetching data ".error);
        }
    }

    useLayoutEffect(() => {
        fetching();
    }, [aa,bb,cc,dd,ee,ff,gg,hh,ii,jj,kk]);

    return ({load, data, tally})
}
