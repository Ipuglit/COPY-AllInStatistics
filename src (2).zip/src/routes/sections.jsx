import { lazy, Suspense, useEffect } from 'react';
import { Outlet, Navigate, useRoutes } from 'react-router-dom';

import DashboardLayout from 'src/layouts/dashboard';
import CSVUploadPage from 'src/pages/csvupload';
import RegisterPage from 'src/pages/register';

import { GoTo } from 'src/hooks/control';

export const IndexPage = lazy(() => import('src/pages/dashboard'));
export const BlogPage = lazy(() => import('src/pages/blog'));
export const UserPage = lazy(() => import('src/pages/user'));
export const UsersPage = lazy(() => import('src/pages/users'));
export const AccountsPage = lazy(() => import('src/pages/accounts'));
export const MyAccountsPage = lazy(() => import('src/pages/myaccounts'));
export const UplinesPage = lazy(() => import('src/pages/uplines'));
export const MyUplinesPage = lazy(() => import('src/pages/myuplines'));
export const HistoryPage = lazy(() => import('src/pages/history'));
export const MyHistoryPage = lazy(() => import('src/pages/myhistory'));
export const RecordsPage = lazy(() => import('src/pages/records'));
export const ClubsPage = lazy(() => import('src/pages/clubs'));
export const ApplicationsPage = lazy(() => import('src/pages/applications'));
export const FXRatesPage = lazy(() => import('src/pages/fxrates'));
export const LoginPage = lazy(() => import('src/pages/login'));
export const ProductsPage = lazy(() => import('src/pages/products'));
export const Page404 = lazy(() => import('src/pages/page-not-found'));

// ----------------------------------------------------------------------

export default function Router() {
  
  const A         = JSON.parse( localStorage.getItem('slk-user') )
  const B         = JSON.parse( localStorage.getItem('slk-route') )
  const Go        = GoTo(A,B)
  const homepage  = { element: <IndexPage />, index: true }

  const routes    = useRoutes([
    {
      element: (
        <DashboardLayout>
          <Suspense>
            <Outlet />
          </Suspense>
        </DashboardLayout>
      ),
      children: [
        { element: <IndexPage />, index: true },
       Go.Apps    ? { path: 'applications', element: <ApplicationsPage /> } : homepage,
       Go.Clubs   ? { path: 'clubs', element: <ClubsPage /> } : homepage,
       Go.Users   ? { path: 'users', element: <UsersPage /> } : homepage,
       Go.Acct     ? { path: 'accounts', element: <AccountsPage /> } : homepage,
       Go.Uplines ? { path: 'uplines', element: <UplinesPage /> } : homepage,
       Go.Records ? { path: 'records', element: <RecordsPage /> } : homepage,
       Go.Rates   ? { path: 'fxrates', element:  <FXRatesPage/> } : homepage,
       Go.CSVUp   ? { path: 'csvupload', element: <CSVUploadPage /> } : homepage,
       Go.History ? { path: 'history', element: <HistoryPage /> } : homepage,
        //goUnions  ? { path: 'unions', element: <UnionsPage /> } : homepage,
        //goNotifs  ? { path: 'notifications', element: <NotificationPage /> } : homepage,
        { path: 'myaccounts', element: <MyAccountsPage /> },
        { path: 'myuplines', element: <MyUplinesPage /> },
        { path: 'myhistory', element: <MyHistoryPage /> },

      ],
    },
    {
      path: 'login',
      element: <LoginPage />,
    },
    {
      path: 'register',
      element: <RegisterPage />,
    },
    {
      path: '404',
      element: <Page404 />,
    },
    {
      path: '*',
      element: <Navigate to="/404" replace />,
    },
  ]);

  return routes;
}
