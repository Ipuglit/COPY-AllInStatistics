import { useEffect, useState } from 'react';
import SvgColor from 'src/components/svg-color';
import { GoTo } from 'src/hooks/control';
// ----------------------------------------------------------------------

const icon = (name) => (
  <SvgColor src={`/assets/icons/navbar/${name}.svg`} sx={{ width: 1, height: 1 }} />
);



export const navPublic  = [
  {
    title: 'dashboard',
    path: '/',
    icon: icon('ic_dashboard'),
  },
  {
    title: 'My accounts',
    path: '/myaccounts',
    icon: icon('ic_accounts3'),
  },
  {
    title: 'My history',
    path: '/myhistory',
    icon: icon('ic_history'),
  },
];




export const navPrivate = ()  => {
  const [Go, setGo] = useState([])

  const navvi  = [];

  useEffect(() => {
    const A = JSON.parse( localStorage.getItem('slk-user') )
    const B = JSON.parse( localStorage.getItem('slk-route') )
    setGo( GoTo(A,B) )
  }, []);

  if ( Go.Records == true ) { 
    navvi.push({
                      title: 'Records',
                      path: '/records',
                      icon: icon('ic_record'),
                    });
  }
  
  if ( Go.Apps == true ) { 
    navvi.push({
                      title: 'Applications',
                      path: '/applications',
                      icon: icon('ic_apps'),
                    });
  }
  
  if ( Go.Clubs == true ) { 
    navvi.push({
                      title: 'Clubs',
                      path: '/clubs',
                      icon: icon('ic_clubs'),
                    });
  }
  
  
  if ( Go.Users == true ) { 
    navvi.push({
                      title: 'Users',
                      path: '/users',
                      icon: icon('ic_users'),
                    });
  }
  
  if ( Go.Acct == true ) { 
    navvi.push({
                      title: 'Accounts',
                      path: '/accounts',
                      icon: icon('ic_accounts3'),
                    });
  }
  
  if ( Go.Uplines == true ) { 
    navvi.push({
                      title: 'Uplines',
                      path: '/uplines',
                      icon: icon('ic_uplines'),
                    });
  }
  
  if ( Go.Rates == true ) { 
    navvi.push({
                      title: 'FX Rates',
                      path: '/fxrates',
                      icon: icon('ic_usd'),
                    });
  }
  
  if ( Go.History == true ) { 
    navvi.push({
                      title: 'History',
                      path: '/history',
                      icon: icon('ic_history'),
                    });
  }
  
  if ( Go.CSVUp == true ) { 
    navvi.push({
                      title: 'CSV Upload',
                      path: '/csvupload',
                      icon: icon('ic_upload'),
                    });
  }
  
  return navvi

}
