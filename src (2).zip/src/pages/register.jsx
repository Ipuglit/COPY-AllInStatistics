import { Helmet } from 'react-helmet-async';

import { Upsert } from 'src/sections/register/';

// ----------------------------------------------------------------------

export default function RegisterPage() {
  return (
    <>
      <Helmet>
        <title> Register | Poker Analytics </title>
      </Helmet>

      <Upsert TheFor="ALL" TheTitle="REGISTER" />
    </>
  );
}
