import { Helmet } from 'react-helmet-async';

import { Viewing } from 'src/sections/records/view/';

// ----------------------------------------------------------------------

export default function RecordsPage() {
  return (
    <>
      <Helmet>
        <title> Records | Poker Analytics </title>
      </Helmet>

      <Viewing TheFor="ALL" TheTitle="RECORDS" />
    </>
  );
}
