
import React, { useState, useEffect } from 'react';
import {
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    TableSortLabel,
    TablePagination,
    Paper,
    TextField,
    Button,
} from '@mui/material';

import { DataGrid, GridToolbar, } from "@mui/x-data-grid";

import { Icon } from '@iconify/react';

import * as Fnc from 'src/hooks/functions'

// ----------------------------------------------------------------------

const initialData = [
    { id: 1, name: 'John Doe', age: 28 },
    { id: 2, name: 'Jane Smith', age: 34 },
    { id: 3, name: 'Alice Johnson', age: 24 },
    { id: 4, name: 'Bob Brown', age: 45 },
    { id: 5, name: 'Charlie White', age: 30 },
    { id: 6, name: 'David Black', age: 29 },
    { id: 7, name: 'Eva Green', age: 23 },
    { id: 8, name: 'Frank Blue', age: 35 },
    { id: 9, name: 'Grace Red', age: 40 },
    { id: 10, name: 'Hank Yellow', age: 31 },
  ];

export default function ViaTableRecord({ DATA_TO, DATA_RE }) {

    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(5);
    const [order, setOrder] = useState('asc');
    const [orderBy, setOrderBy] = useState('name');
    const [searchQuery, setSearchQuery] = useState('');
    const [searchBy, setsearchBy] = useState('playerID');

    // ==================================== *_* ====================================
    console.log(DATA_TO)
    console.log(initialData)

    // ==================================== *_* ====================================

    const handlePAGINATION = (event, newPage) => {
      setPage(newPage);
    };
  
    const handlePAGEROWS = (event) => {
      setRowsPerPage(parseInt(event.target.value, 10));
      setPage(0);
    };
  
    const handleSORT = (property) => {
      const isAsc = orderBy === property && order === 'asc';
      setOrder(isAsc ? 'desc' : 'asc');
      setOrderBy(property);
    };
  
    const handleSEARCH = (event) => {
      setSearchQuery(event.target.value);
    };
  
    const searchTABLE = DATA_TO.filter((row) =>
      row[searchBy].includes(searchQuery)
    );
  
    const sortedData = [...searchTABLE].sort((a, b) => {
      if (a[orderBy] < b[orderBy]) return order === 'asc' ? -1 : 1;
      if (a[orderBy] > b[orderBy]) return order === 'asc' ? 1 : -1;
      return 0;
    });



    // ==================================== *_* ====================================

    const viewDetails =(i)=>{
        console.log(i)
    }

    const iHEADER =(i,ii)=>{
        return <TableCell>
                    <TableSortLabel
                    active={orderBy === i}
                    direction={orderBy === i ? order : 'asc'}
                    onClick={() => handleSORT(i)} >
                    {ii}
                    </TableSortLabel>
                </TableCell>
    }

    const iDATE =(i,ii)=>{
        return (<>
                    <span>{i} </span> 
                    <br></br>
                    <span>{ii}</span> 
                </>)

    }

    const iCLUB =(i,ii,iii)=>{
        const e = i == '' || i == 0 || i == null ? 'None' : i 
        const ee = ii == 0 || ii == null ? 'No rake' : ii+'% rake'
        return (<>
                    <span>{iii}</span>
                    <br></br>
                    <b>{e} </b> 
                    <br></br>
                    <span>{ee}</span> 
                </>)
    }

    const iPLAYER =(i,ii)=>{
        return (<>
                    <b>{i} </b> 
                {ii == '' || ii == null || ii == 0? null :
                <>
                    <br></br>
                    <span>{ii}</span> 
                </>}
                </>)
    }

    const iUPLINE =(i,ii)=>{
        const e = i == '' || i == 0 || i == null ? 'None' : i 
        const ee = ii == 0 || ii == null ? 'No rake' : ii+'% rake'
        return (<>
                    <b>{e} </b> 
                {e != 'None' ?
                <>
                    <br></br>
                    <span>{ee}</span> 
                </> : null }
                </>)
    }

    const iFXRATE =(i,ii,iii)=>{
        return (<>
            <span>{iii}</span>
            <br></br>
            <b>{i} </b> 
            <br></br>
            <span>per {ii}</span> 
        </>)

    }

    const iACTION = (i) => {
        return (
                <Button size="small"  onClick={() => viewDetails(i)}
                    endIcon={<Icon icon="eva:arrow-ios-forward-fill" color='purple' />} >
                    <span style={{color: "violet"}}> View </span>
                </Button>
                );
    }

  return (
    <Paper>
    <TextField
     size='small'
      variant="outlined"
      placeholder="Search by name"
      value={searchQuery}
      onChange={handleSEARCH}
      style={{ margin: '16px' }}
    />
    <TableContainer>
      <Table>

        <TableHead>
          <TableRow>
            {iHEADER('id','#')}
            {iHEADER('dateOpen','Date')}
            {iHEADER('playerID','Player')}
            {iHEADER('clubName','Club')}
            {iHEADER('uplineID','Upline')}
            {iHEADER('fxUSD','USD')}
            <TableCell>Action</TableCell>
          </TableRow>
        </TableHead>

        <TableBody>
          {sortedData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
            .map((row) => (
              <TableRow key={row.id}>
                <TableCell>{row.increment}</TableCell>
                <TableCell style={{minWidth:'120px'}}>{iDATE(row.dateOpen,row.dateClose)}</TableCell>
                <TableCell style={{minWidth:'130px'}}>{iPLAYER(row.playerID,row.playerUser)}</TableCell>
                <TableCell style={{minWidth:'130px'}}>{iCLUB(row.clubName,row.clubPercent,row.appName)}</TableCell>
                <TableCell style={{minWidth:'130px'}}>{iUPLINE(row.uplineID,row.uplinePercent)}</TableCell>
                <TableCell style={{minWidth:'130px'}}>{iFXRATE(row.fxUSD,row.fxCurrency,row.fxDate)}</TableCell>
                <TableCell>{row.age}</TableCell>
                <TableCell>{iACTION(row)}</TableCell>
              </TableRow>
            ))}
        </TableBody>
      </Table>
    </TableContainer>
    <TablePagination
      rowsPerPageOptions={[5, 15, 30]}
      component="div"
      count={searchTABLE.length}
      rowsPerPage={rowsPerPage}
      page={page}
      onPageChange={handlePAGINATION}
      onRowsPerPageChange={handlePAGEROWS}
    />
  </Paper>
  );
};
