import React, { useState, useEffect } from 'react';
import Papa from 'papaparse'
import axios from 'axios';

import * as XLSX from 'xlsx'; // Import XLSX library
import numeral from 'numeral';

import {Link,Box,Button,Autocomplete,Chip,Divider,TextField,IconButton,InputAdornment,Tooltip,FormControl,Typography,Avatar,ListItemAvatar,List,ListItem,ListItemText,ListItemIcon } from '@mui/material';

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';

import Grid from '@mui/material/Unstable_Grid2';

import { RawClubs } from 'src/hooks/raw/clubs'
import { RawAccounts } from 'src/hooks/raw/accounts'
import { RawFXRates } from 'src/hooks/raw/'


import { RawUplines } from 'src/hooks/raw/uplines'

import { UpsertData, UploadLink } from 'src/hooks/upsert/upsert-data'

import { UpdateGames, Results, UpdatePlayer, UpdateFXRate  } from './modals'

import * as Fnc from 'src/hooks/functions'
import * as Cls from 'src/hooks/classes'

import {importXLXS} from './hooks/function'

import { Icon } from '@iconify/react';

import {AlertSnack} from 'src/items/alert_snack'

// ---------------------------------------------------------------------- PIECES
// ---------------------------------------------------------------------- PIECES



const RenderDateClosed = ({Val,Ret,Ndx}) => {

  const [dateClosed,setdateClosed]    = useState(Val.DATECLOSED)
            
  const onChanging = (i) => {
    setdateClosed(i)   
    Val['DATECLOSED'] = i
    Ret({index: Ndx, values: Val})
  }

  return (
          <TextField
                      label="Date Closed"
                      type="date"
                      error={dateClosed ? false : true}
                      value={dateClosed}
                      size='small'
                      sx={Cls.inputDate('12','14')}
                      InputLabelProps={{ shrink: true,  }}
                      onChange={(e) => onChanging(e.target.value)}
          />
  );
};


// ----------------------------------------------------------------------

export default function UploadRecords({ReData}) {

    const rawClubs                                = RawClubs('ALL').data;
    const rawAccounts                             = RawAccounts('ALL','ALL').data;
    const rawUplines                              = RawUplines('ALL','ACTIVE').data;
    const rawFXRates                              = RawFXRates('ALL','ALL').data;

    const [FILEType, setFILEType]                 = useState(null);
    const [FILETitle, setFILETitle]               = useState(null);
    const [JSONConverted, setJSONConverted]       = useState([]);

    const [JSONCalculate, setJSONCalculate]       = useState([]);

    const [JSONUpdates, setJSONUpdates]           = useState([]);
    const [JSONRendering, setJSONRendering]       = useState([]);
    
    const [onAlert, setonAlert]                   = useState({open:false,type:'',message:''});

    const [sumWINLOSS, setsumWINLOSS]             = useState(0);
    const [sumBONUS, setsumBONUS]                 = useState(0);
    const [sumChanges, setsumChanges]             = useState(0);

    const [JSONWinLossBon, setJSONWinLossBon]     = useState([]);
    const [JSONPlayer, setJSONPlayer]             = useState([]);
    const [JSONFXRates, setJSONFXRates]           = useState([]);


    async function proceedSubmit(i,ii) {

      try {
        
        const response = await axios.post(UploadLink(ii),UpsertData(i));

        const feed =  response.data;
        
        console.log(JSON.stringify(feed,null,2))

      } catch (error) {
        alert("FAILED CSV ! "+error)
      }

    }

    //const [file, setFile] = useState(null);
  
    const submitCalculation = (i) => {

        const x = i.find((u) => ( u.PLAYERSUB == 'WRONG' || u.CLUBSUB == 'WRONG' || u.CLUBSUB == 'NONE' ) ); 

        if(x){
          console.log('INCOMPLETE')
        } else {
          setJSONCalculate(i)
        }
    };

    const handleFileChanges = (event) => {
      const uploadedFile = event.target.files[0];
      setFile(uploadedFile);
    };


    const Uploadings = async (event) => {
      const file = event.target.files[0];
      try {
        const jsonData = await importXLXS(file,rawClubs,rawAccounts,rawUplines);
        setJSONRendering(jsonData)
        console.log('Parsed JSON data from XLSX:', jsonData);
      } catch (error) {
        setJSONRendering([])
        console.error('Error parsing XLSX file:', error);
      }
    };
    
    const Renderings = async (event) => {
      const file = event.target.files[0];
      try {
        const jsonData = await importXLXS(file,rawClubs,rawAccounts,rawUplines);
        console.log('Parsed JSON data from XLSX:', jsonData);
      } catch (error) {
        console.error('Error parsing XLSX file:', error);
      }
    };

    const handleFileChange = (event) => {

          const file = event.target.files[0];

          if (!file) {
            setFILEType('INVALID')
            const JSONChecked = Fnc.JSONChecking('ERR','')
            setJSONConverted(JSONChecked)
            ReData(JSONChecked)
            return;
          }
          console.log('Uploading...');
          
          const reader = new FileReader();
          reader.readAsArrayBuffer(file);
          reader.onprogress = (event) => {
            const progress = Math.round((event.loaded / event.total) * 100);
            console.log(`Upload progress: ${progress}%`);
          };
            reader.onload = (event) => {
                const arrayBuffer = event.target.result;
                const workbook = XLSX.read(arrayBuffer, { type: 'array', cellDates: true});
                const sheetFIRST = workbook.SheetNames[0]; // Get 1st sheet name
                const worksheet = workbook.Sheets[sheetFIRST];
                const sheetFULLDATA = XLSX.utils.sheet_to_json(worksheet, { header: 1 }); // Get rows content

                setFILETitle(sheetFIRST)

                if(sheetFULLDATA[0][0] == 'DATE CLOSED' && sheetFULLDATA[0][1] == 'CLUB' && sheetFULLDATA[0][2] == 'PLAYER ID' && sheetFULLDATA[0][3] == 'WIN/LOSS' && sheetFULLDATA[0][4] == 'BONUS'){
                    
                    setFILEType('SHORT')
                    const headerSHORT = sheetFULLDATA[0].map(i => i.replace(/[^a-zA-Z0-9]/g, ""));
                          headerSHORT[3] = 'WINLOSS_TOTAL'
                          headerSHORT[4] = 'BONUS_TOTAL'

                    const dataSHORT = sheetFULLDATA.splice(1)

                    const JSONChecked = Fnc.JSONChecking(headerSHORT,dataSHORT,'SHORT',rawClubs,rawAccounts,rawUplines)

                    setJSONConverted(JSONChecked)
                    ReData(JSONChecked)

                } else if(sheetFULLDATA[1][0] == 'DATE CLOSED' && sheetFULLDATA[1][1] == 'CLUB' && sheetFULLDATA[1][2] == 'PLAYER ID' && sheetFULLDATA[1][3] == 'NLH'){
                    
                    setFILEType('LONG')
                    const headerLONG = sheetFULLDATA[1].map(i => i.replace(/[^a-zA-Z0-9]/g, "").toUpperCase());
                    const dataLONG = sheetFULLDATA.splice(2)

                    for (let i = 3; i <= 15; i++) {
                      headerLONG[i] = 'WINLOSS_'+headerLONG[i];
                    }

                    for (let i = 16; i < headerLONG.length; i++) {
                      headerLONG[i] = 'BONUS_'+headerLONG[i];
                    }
                    
                    const JSONChecked = Fnc.JSONChecking(headerLONG,dataLONG,'LONG',rawClubs,rawAccounts,rawUplines)

                    setJSONConverted(JSONChecked)
                    ReData(JSONChecked)

                }
                setsumChanges(8)
          };

          reader.onerror = (error) => {
            setFILEType('INVALID')
            const JSONChecked = Fnc.JSONChecking('ERR','')
            setJSONConverted(JSONChecked)
            ReData(JSONChecked)
          };
    };



    const deleteRow = (index) => {
        const updatedData = [...JSONConverted]; // Create array copy 
        updatedData.splice(index, 1);
        setJSONConverted(updatedData);
        ReData(updatedData)

    };

    const checkWinLossBonus = (i,type) => {
        if( 
          i[type +'_'+ 'NLH']     != null && 
          i[type +'_'+ 'FLH']     != null && 
          i[type +'_'+ '6']       != null &&
          i[type +'_'+ 'PLOHI']   != null && 
          i[type +'_'+ 'PLOHILO'] != null && 
          i[type +'_'+ 'FLOHI']   != null &&
          i[type +'_'+ 'FLOHILO'] != null && 
          i[type +'_'+ 'MIXED']   != null && 
          i[type +'_'+ 'OFC']     != null &&
          i[type +'_'+ 'MTT']     != null && 
          i[type +'_'+ 'SNG']     != null && 
          i[type +'_'+ 'SPIN']    != null && 
          i[type +'_'+ 'OTHER'+type] !=null
      ){
        return true //WITH VALUE
      } else {
        return false //NO VALUE
      }
    }



  

    const OnAlerting =(open,type,message,time)=>{

        setonAlert({open:open,type:type,message:message})

        const T = setTimeout(() => {
            setonAlert({open:false,type:'',message:''})
        }, time ? time : 2500);
        return () => clearTimeout(T);

    }

    const Returned_WinLossBon =(i)=>{

      const updatedData = [...JSONConverted]; // Create array copy 
      updatedData[i.index][i.type+'_TOTAL'] = i.total;

      i.values.map((e,index) => {
        if(e.title == 'OTHER'){
          updatedData[i.index][i.type+'_OTHER'+i.type] = e.value;
        } else {
          updatedData[i.index][i.type+'_'+e.title] = e.value;
        }
      })

      OnAlerting(true,'success',i.type == 'WINLOSS' ? 'Win/Loss details saved!' : 'Bonus details saved!')

      setJSONConverted(updatedData);
      ReData(updatedData)

      setsumChanges(i.total)

    }

    const Returned_Player =(i)=>{

      const updatedData = [...JSONConverted]; // Create array copy 
      updatedData[i.index]['PLAYERID']        = i['values']['playerID'];
      updatedData[i.index]['PLAYERNAME']      = i['values']['playerName'];
      updatedData[i.index]['PLAYERSUB']       = i['values']['isplayerApp'];
      updatedData[i.index]['UPLINEID']        = i['values']['uplineID'];
      updatedData[i.index]['UPLINENAME']      = i['values']['uplineName'];
      updatedData[i.index]['UPLINEPERCENT']   = i['values']['uplinePercent'];

      updatedData[i.index]['APPID']           = i['values']['appID'];
      updatedData[i.index]['APPNAME']         = i['values']['appName'];
      updatedData[i.index]['CLUBIDD']         = i['values']['clubIDD'];
      updatedData[i.index]['CLUB']            = i['values']['clubName'];
      updatedData[i.index]['CLUBPERCENT']     = i['values']['clubPercent'];
      updatedData[i.index]['CLUBSUB']         = i['values']['isplayerApp'];

      OnAlerting(true,'success','Player details saved!')

      setJSONConverted(updatedData);
      ReData(updatedData)

    }

    const Returned_FXRate =(i)=>{

      const updatedData = [...JSONConverted]; // Create array copy 
      updatedData[i.index]['FXUSD']           = i['values']['fxUSD'];
      updatedData[i.index]['FXCURRENCY']      = i['values']['fxCurrency'];
      updatedData[i.index]['FXDATE']          = i['values']['fxDate'];
      updatedData[i.index]['FXPROVIDER']      = i['values']['fxProvider'];

      OnAlerting(true,'success','FX Rates saved!')

      setJSONConverted(updatedData);
      ReData(updatedData)

    }
    

    useEffect(() => {

        let WL = 0;
        let BN = 0;

        JSONConverted.forEach( num => {
            WL += parseFloat(num.WINLOSS_TOTAL);
            BN += parseFloat(num.BONUS_TOTAL);
          })
          
          setsumWINLOSS(numeral(WL).format('0,0.000'))
          setsumBONUS(numeral(BN).format('0,0.000'))

          
      }, [sumChanges]);


      const returnedDateClosed =(i)=> {

        const T = setTimeout(() => {

            const x = JSONUpdates.findIndex(u => ( u.index == i.index ) ); 

            if (x !== -1) {

                const newData = [...JSONUpdates]; // Create a copy
                newData[x] = i; 
                setJSONUpdates(newData);

            } else {

                const newData = [...JSONUpdates, i];
                setJSONUpdates(newData);

            }

        }, 0);
        return () => clearTimeout(T);  
        
      }

      const pushJSON = () =>{
        const i = JSONUpdates
        const x = JSONConverted.findIndex(u => ( u.index == i.index ) );

        if(x){
                const newData = [...JSONConverted]; // Create a copy
                newData[x] = i.values; 
                setJSONConverted(newData);
        }

      }



  // --- STARTS
  // --- STARTS

    const RenderTableItems = JSONConverted.map((i,index) => { 

        const updateDataItems = async (val) => {
              try {
                console.log('Submitting...');
                await updateDataItems(val)
                console.log('Submitted!');
              } catch (error) {
                console.error('Error fetching data:', error);
              }
        };

          const editPlayer = () => {

            const DEF = rawUplines.find((u) => ( u.playerID == i['PLAYERID'] && u.clubIDD == i['CLUBIDD'] ) );        

            setJSONPlayer({
                            DIALOG:       true,
                            INDEX:        index,
                            ITEMS:       {
                                            dateClosed:     i['DATECLOSED'] ? i['DATECLOSED'] : '',
                                            playerID:       i['PLAYERID'] ? i['PLAYERID'] : '',
                                            playerName:     i['PLAYERNAME'] ? i['PLAYERNAME'] : '',
                                            isplayerApp:    i['PLAYERSUB'] ? i['PLAYERSUB'] : '',
                                            isApp:          i['PLAYERSUB'] ? i['PLAYERSUB'] : '',
                                            appID:          i['APPID'] ? i['APPID'] : '0',
                                            appName:        i['APPNAME'] ? i['APPNAME'] : '',
                                            clubIDD:        i['CLUBIDD'] ? i['CLUBIDD'] : '0',
                                            clubName:       i['CLUB'] ? i['CLUB'] : '',
                                            clubPercent:    i['CLUBPERCENT'] ? i['CLUBPERCENT'] : '0',
                                            uplineID:       i['UPLINEID'] ? i['UPLINEID'] : '0',
                                            uplineName:     i['UPLINENAME'] ? i['UPLINENAME'] : '',
                                            uplinePercent:  i['UPLINEPERCENT'] ? i['UPLINEPERCENT'] : '0',
                                          },
                            ACCOUNTS:     rawAccounts,
                            UPLINES:      rawUplines,
                            CLUBS:        rawClubs,
                            UPLINED:      {id: i['UPLINEID'], name: i['UPLINENAME'], percent: i['UPLINEPERCENT']},
                            DEFAULT:      DEF ? DEF : '',
            })

          }

          const editWinLossBonus = (type) => {

            setJSONWinLossBon({
                                DIALOG:   true,
                                INDEX:    index,
                                TYPE:     type,
                                PLAYER:   'Player ID: '+i['PLAYERID']+(i['PLAYERNAME'] ? ' ('+i['PLAYERNAME']+')' : '' ),
                                CLUB:     i['CLUB'],
                                DATE:     i['DATECLOSED'],
                                TOTAL:    i[type +'_'+ 'TOTAL'],
                                GAMES:    [{
                                            id:     1,
                                            title: 'OTHER',
                                            syn:    "Others",
                                            value:  i[type +'_'+ 'OTHER'+type],
                                          },{
                                            id:     2,
                                            title:  "NLH",
                                            syn:    "NLH (No-Limit Hold'em)",
                                            value:  i[type +'_'+ 'NLH'],
                                          },{
                                            id:     3,
                                            title: 'FLH',
                                            syn:    "FLH (Fixed Limit Hold'em)",
                                            value:  i[type +'_'+ 'FLH'],
                                          },{
                                            id:     4,
                                            title: '6',
                                            syn:    "6+ (Six-Plus Poker)",
                                            value:  i[type +'_'+ '6'],
                                          },{
                                            id:     5,
                                            title: 'PLOHI',
                                            syn:    "PLO Hi (Pot Limit Omaha Hi)",
                                            value:  i[type +'_'+ 'PLOHI'],
                                          },{
                                            id:     6,
                                            title: 'PLOHILO',
                                            syn:    "PLO Hi/Lo (Pot Limit Omaha Hi-Lo)",
                                            value:  i[type +'_'+ 'PLOHILO'],
                                          },{
                                            id:     7,
                                            title: 'FLOHI',
                                            syn:    "FLO Hi (Fixed Limit Omaha Hi)",
                                            value:  i[type +'_'+ 'FLOHI'],
                                          },{
                                            id:     8,
                                            title: 'FLOHILO',
                                            syn:    "FLO Hi-Lo (Fixed Limit Omaha Hi-Lo)",
                                            value:  i[type +'_'+ 'FLOHILO'],
                                          },{
                                            id:     9,
                                            title: 'MIXED',
                                            syn:    "Mixed (Mix Poker)",
                                            value:  i[type +'_'+ 'MIXED'],
                                          },{
                                            id:     10,
                                            title: 'OFC',
                                            syn:    "OFC (Open-face Chinese Poker)",
                                            value:  i[type +'_'+ 'OFC'],
                                          },{
                                            id:     11,
                                            title: 'MTT',
                                            syn:    "MTT (Multi-Table Tournaments)",
                                            value:  i[type +'_'+ 'MTT'],
                                          },{
                                            id:     12,
                                            title: 'SNG',
                                            syn:    "SNG (Sit'n Gos)",
                                            value:  i[type +'_'+ 'SNG'],
                                          },{
                                            id:     13,
                                            title: 'SPIN',
                                            syn:    "SPIN (Spin-and-Go)",
                                            value:  i[type +'_'+ 'SPIN'],
                                          },],
                              })
            };

            const editFXRate = () => {

              //const DEF = rawFXRates.find((u) => ( u.playerID == i['PLAYERID'] && u.clubIDD == i['CLUBIDD'] ) );        
  
              setJSONFXRates({
                              DIALOG:       true,
                              INDEX:        index,
                              ITEMS:       {
                                              dateClosed:     i['DATECLOSED'] ? i['DATECLOSED'] : '',
                                              fxUSD:          i['FXUSD'] ? i['FXUSD'] : 0,
                                              fxCurrency:     i['FXCURRENCY'] ? i['FXCURRENCY'] : 'USD',
                                              fxProvider:     i['FXPROVIDER'] ? i['FXPROVIDER'] : '',
                                              fxDate:         i['FXDATE'] ? i['FXDATE'] : '',
                                            },
                              FXRATES:      rawFXRates,
              })
  
            }

        return (
          <TableRow key={index}>
              
              <TableCell>      
                <RenderDateClosed Val={i} Ret={returnedDateClosed} Ndx={index} />
              </TableCell>

              <TableCell sx={{'&:hover': { cursor: 'pointer' },minWidth:180}}>
                  <Box display="flex" alignItems="center" sx={{ p: .2, border: i.CLUBSUB != 'NONE' ? '1px dashed grey' : '1px dashed red' }} 
                        onClick={() => editPlayer()}>
                        <ListItem disablePadding >
                          <ListItemIcon sx={{ minWidth: 23, paddingLeft: 1.5, paddingRight: 1 }}>
                          <Icon icon="hugeicons:pencil-edit-01" color='violet' width={'22px'}  />
                          </ListItemIcon>
                          <ListItemText primary={i.CLUB} 
                                        secondary={i.CLUBSUB != 'NONE' ? '' : 'NOT FOUND' }
                                        primaryTypographyProps={i.CLUBSUB == 'NONE' || i.CLUBSUB == 'WRONG' ?  { fontSize: 13,marginTop:'-6px' }  : { fontSize: 13 } }
                                        secondaryTypographyProps={i.CLUBSUB == 'NONE' || i.CLUBSUB == 'WRONG' ?
                                                                      { fontSize: 11,color:'#ff2f1c',marginTop:'-6px',marginBottom:'-8px',fontWeight:'bold' }
                                                                      :
                                                                      { fontSize: 11,color:'#ff2f1c',fontWeight:'bold' }
                                                                  } />
                        </ListItem>
                  </Box>
              </TableCell>

              <TableCell sx={{'&:hover': { cursor: 'pointer' },minWidth:170}}>

                  <Box  display="flex" alignItems="center" 
                        sx={{ p: .2, border: i.PLAYERSUB == 'NEW' ? '1px dashed orange' : i.PLAYERSUB == 'WRONG' ? '1px dashed red' : '1px dashed grey' }} 
                        onClick={() => editPlayer()}>
                        <ListItem disablePadding >
                            <ListItemIcon sx={{ minWidth: 23, paddingLeft: 1.5, paddingRight: 1 }}>
                                <Icon icon="hugeicons:pencil-edit-01" color='violet' width={'22px'}  />
                            </ListItemIcon>
                            <ListItemText primary={i.PLAYERID} 
                                        secondary={i.PLAYERSUB == 'NEW' ? 'NEW PLAYER?' :i.PLAYERSUB == 'NONE' ? 'NO PLAYER' : i.PLAYERSUB == 'WRONG' ? 'WRONG GAME!' : i.PLAYERNAME }
                                        primaryTypographyProps={{ fontSize: 13,marginTop:'-6.5px' }}
                                        secondaryTypographyProps={{ fontSize: 11,marginTop:'-6px',marginBottom:'-7.5px',color: i.PLAYERSUB == 'NEW' ? 'orange' : i.PLAYERSUB == 'WRONG' ? '#ff2f1c' : 'grey',fontWeight:'bold' }} />
                        </ListItem>
                  </Box>

              </TableCell>

              <TableCell sx={{'&:hover': { cursor: 'pointer' },minWidth:130}} >
                  <Box display="flex" alignItems="center" sx={{ p: .2, border: '1px dashed grey' }} 
                        onClick={() => editWinLossBonus('WINLOSS')}>
                        <ListItem disablePadding >
                          <ListItemIcon sx={{ minWidth: 23, paddingLeft: 1.5, paddingRight: 1 }} >
                          <Icon icon="hugeicons:pencil-edit-01" color='violet' width={'22px'}  />
                          </ListItemIcon>
                          <ListItemText primary={i.WINLOSS_TOTAL}  primaryTypographyProps={{ fontSize: 13, }} />
                        </ListItem>
                  </Box>
              </TableCell>

              <TableCell sx={{'&:hover': { cursor: 'pointer' },minWidth:130}} >
                  <Box display="flex" alignItems="center" sx={{ p: .2, border: '1px dashed grey' }} 
                        onClick={() => editWinLossBonus('BONUS')}>
                        <ListItem disablePadding >
                          <ListItemIcon sx={{ minWidth: 23, paddingLeft: 1.5, paddingRight: 1 }}>
                          <Icon icon="hugeicons:pencil-edit-01" color='violet' width={'22px'}  />
                          </ListItemIcon>
                          <ListItemText primary={i.BONUS_TOTAL} primaryTypographyProps={{ fontSize: 13, }}/>
                        </ListItem>
                  </Box>
              </TableCell>

              <TableCell sx={{'&:hover': { cursor: 'pointer' },minWidth:140}} >
                  <Box display="flex" alignItems="center" sx={{ p: .2, border: '1px dashed grey' }} 
                        onClick={() => editFXRate('FXRATE')}>
                        <ListItem disablePadding >
                          <ListItemIcon sx={{ minWidth: 23, paddingLeft: 1.5, paddingRight: 1 }}>
                          <Icon icon="pepicons-print:dollar" color='violet' width={'22px'}  />
                          </ListItemIcon>
                          <ListItemText primary={i.FXUSD} 
                                        secondary={i.FXCURRENCY ? i.FXCURRENCY : 'NONE!'}
                                        primaryTypographyProps={{ fontSize: 13,marginTop:'-6.5px' }}
                                        secondaryTypographyProps={{ fontSize: 11,marginTop:'-6px',marginBottom:'-7.5px',color: i.FXCURRENCY == 'NEW' ? 'orange' : i.FXCURRENCY == 'WRONG' ? '#ff2f1c' : 'grey',fontWeight:'bold' }} />
                        </ListItem>
                  </Box>
              </TableCell>

              <TableCell align="right">
                <Tooltip title="Delete">
                    <IconButton onClick={() => deleteRow(index)}>
                        <Icon icon="solar:trash-bin-trash-bold-duotone" color='red' width={'25px'} sx={{ mr: 0.3 }}  />
                    </IconButton>
                </Tooltip>
              </TableCell>
            </TableRow>
        )
        
    }) // --- ENDS


  return (
    <>


      <input type="file" accept=".xlsx, .xlsm, .xlsb, .csv" onChange={Uploadings} />

      <br/>
      <br/>
      <br/>
      <Link href='/csv/template_records_short.xlsx'>Records: Excel Short Template</Link>
      <br/>
      <Link href='/csv/template_records_long.xlsx'>Records: Excel Long Template</Link>
      <br/>
      <p>{FILEType} : {FILETitle}</p>

    <Grid container>

    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 700 }} aria-label="spanning table">
        <TableHead>
          <TableRow>
            <TableCell>Date Closed</TableCell>
            <TableCell>Club</TableCell>
            <TableCell>Player</TableCell>
            <TableCell>Win/Loss Total</TableCell>
            <TableCell>Bonus Total</TableCell>
            <TableCell>USD Rate</TableCell>
            <TableCell></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>

          {RenderTableItems}

          <TableRow>
            <TableCell rowSpan={1} />
            <TableCell align="right"></TableCell>
          </TableRow>

          <TableRow>
            <TableCell colSpan={1}>WIN/LOSS</TableCell>
            <TableCell align="right">{sumWINLOSS}</TableCell>
          </TableRow>

          <TableRow>
            <TableCell colSpan={1}>BONUS</TableCell>
            <TableCell align="right">{sumBONUS}</TableCell>
          </TableRow>

          <TableRow>
            <TableCell colSpan={4}></TableCell>
            <TableCell align="right">
            <Button variant="contained" onClick={()=>submitCalculation(JSONConverted)}>Calculate</Button>
            </TableCell>
          </TableRow>

        </TableBody>
      </Table>
    </TableContainer>

    </Grid>


    <UpdateGames dataReceived={JSONWinLossBon} dataSubmitted={Returned_WinLossBon}/>
    <UpdatePlayer dataReceived={JSONPlayer} dataSubmitted={Returned_Player}/>
    <UpdateFXRate dataReceived={JSONFXRates} dataSubmitted={Returned_FXRate}/>

    <Results dataReceived={JSONCalculate} />
    <pre style={{fontSize:'8px'}}>{
  JSON.stringify(JSONConverted,null,2)
    }</pre>
    {
      onAlert.open ? 
      AlertSnack(onAlert.type,onAlert.message)
      :
      null
    }
    </>
  );
}

