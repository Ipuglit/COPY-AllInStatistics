export { default as UpdateGames } from './games';
export { default as UpdateFXRate } from './fxrate';
export { default as UpdateUPPlayer } from './upplayer';
export { default as Results } from './result';
export { default as UpdateDateClosed } from './dateclosed';
export { default as UpdateClub } from './club';
