
import { useState, useEffect } from 'react';
import axios from 'axios';

import {
  Select,
  Autocomplete,
  Chip,
  Divider,
  Dialog,
  DialogContent,
  DialogTitle,
  DialogActions,
  TextField,
  InputAdornment,
  IconButton,
  Button,
  Grid,
  Typography,
} from '@mui/material';


import { Icon } from '@iconify/react';

import * as Fnc from 'src/hooks/functions'
import * as Cls from 'src/hooks/classes'

import {Compute} from '../hooks/calculations'

import {AlertSnack} from 'src/items/alert_snack'
import { nullFormat } from 'numeral';



export default function Results({dataReceived}) {
    

      const tableRows = dataReceived.map((i,index) => {

        const Calc = (e) => {
                                return Compute({ 
                                    what:   e,
                                    values: i,
                                })
                            } 

        const TWinLoss                  = Calc('Total_WinLoss')
        const TBonus                    = Calc('Total_Bonus')
        const TWinLossBonus             = Calc('Total_WinLossBonus')
        const BonusRakeUpline           = Calc('Upline_BonusRake')
        const BonusRakeAgency           = Calc('Agency_BonusRake')
        const AgencyAction              = Calc('Agency_Action')

        return (
                    <tr key={index}>
                        <td>{i.DATEOPENNED}</td>
                        <td>{i.DATECLOSED}</td>
                        <td>{i.APPNAME}</td>
                        <td>
                          {'ID: '+i.CLUBIDD}
                          <br></br>
                          {i.CLUB}
                        </td>
                        <td>{i.CLUBPERCENT}%</td>
                        <td>{i.PLAYERID}</td>
                        <td>{i.UPLINEID}</td>
                        <td>{i.UPLINEPERCENT ? i.UPLINEPERCENT+'%' : null}</td>
                        <td>${i.FXUSD}</td>

                        <td>
                            {TWinLoss.base == TWinLoss.usd ? 
                              'USD '+TWinLoss.usd
                              : 
                              (<>
                                {i.FXCURRENCY+' '+ TWinLoss.base}
                                <br/>
                                {'USD ' + TWinLoss.usd}
                              </>)
                              }
                        </td>
                        <td>
                            {TBonus.base == TBonus.usd ? 
                              'USD '+TBonus.usd
                              : 
                              (<>
                                {i.FXCURRENCY+' '+ TBonus.base}
                                <br/>
                                {'USD ' + TBonus.usd}
                              </>)
                              }
                        </td>

                        <td>
                            {TWinLossBonus.base == TWinLossBonus.usd ? 
                              'USD '+TWinLossBonus.usd
                              : 
                              (<>
                                {i.FXCURRENCY+' '+ TWinLossBonus.base}
                                <br/>
                                {'USD ' + TWinLossBonus.usd}
                              </>)
                              }
                        </td>
                        <td>
                            {BonusRakeUpline.base == BonusRakeUpline.usd ? 
                              'USD '+BonusRakeUpline.usd
                              : 
                              (<>
                                {i.FXCURRENCY+' '+ BonusRakeUpline.base}
                                <br/>
                                {'USD ' + BonusRakeUpline.usd}
                              </>)
                              }
                        </td>
                        <td>
                            {BonusRakeAgency.base == BonusRakeAgency.usd ? 
                              'USD '+BonusRakeAgency.usd
                              : 
                              (<>
                                {i.FXCURRENCY+' '+ BonusRakeAgency.base}
                                <br/>
                                {'USD ' + BonusRakeAgency.usd}
                              </>)
                              }
                        </td>
                        <td>
                            {AgencyAction.base == AgencyAction.usd ? 
                              'USD '+AgencyAction.usd
                              : 
                              (<>
                                {i.FXCURRENCY+' '+ AgencyAction.base}
                                <br/>
                                {'USD ' + AgencyAction.usd}
                              </>)
                              }
                        </td>

                    </tr>
                );
        })


  return (
        <>
        {
        //JSON.stringify(dataReceived,null,2)
        }
            <table id="sanpletabl" style={{marginTop:'20px'}}>
            <thead>
            <tr>
                                <th>Date Openned</th>
                                <th>Date Closed</th>
                                <th>Poker Game</th>
                                <th>Club</th>
                                <th>Rake%</th>
                                <th>Player</th>
                                <th>Upline</th>
                                <th>Rake%</th>
                                <th>Fx USD</th>
                                <th>Total Win/Loss</th>
                                <th>Total Bonus</th>
                                <th>Result</th>
                                <th>Upline Rakeback</th>
                                <th>Agency Rakeback</th>
                                <th>Agency Action</th>
            </tr>
            </thead>
            <tbody>
            { tableRows }
            </tbody>
            </table>

        </>
  );
}