export { default as UploadClubs } from './clubs/view';
export { default as UploadRecords } from './records/view';
