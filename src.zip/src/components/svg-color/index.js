export { default } from './svg-color';
