export { default as ApplicationsView } from './view';
