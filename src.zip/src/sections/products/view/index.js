export { default as ProductsView } from './view';
